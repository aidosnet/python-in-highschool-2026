"""Exercise: calculate powers using recursion."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"


def power(base, exponent):
    """Return base raised to exponent.

    Assume exponent is an integer greater than or equal to 0.

    >>> power(2, 0)
    1
    >>> power(2, 5)
    32
    >>> power(3, 4)
    81
    """
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)
