"""Exercise: use recursion to sum the digits of an integer."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"


def digit_sum(number):
    """Return the sum of the digits of number.

    >>> digit_sum(0)
    0
    >>> digit_sum(1234)
    10
    >>> digit_sum(-905)
    14
    """
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)
