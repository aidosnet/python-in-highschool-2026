"""Exercise: sum natural numbers with a loop."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"


def natural_sum(limit):
    """Return the sum of natural numbers from 1 to limit.

    >>> natural_sum(1)
    1
    >>> natural_sum(5)
    15
    >>> natural_sum(10)
    55
    """
    pass


def gauss_sum(limit):
    """Return the same sum using Gauss's formula.

    >>> gauss_sum(5)
    15
    >>> gauss_sum(10)
    55
    """
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)
