"""Exercise: convert Celsius temperatures and classify the result."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"


def convert_celsius(celsius_temperature):
    """Return Fahrenheit and Kelvin temperatures.

    >>> convert_celsius(0)
    (32.0, 273.15)
    >>> convert_celsius(100)
    (212.0, 373.15)
    """
    pass


def classify_temperature(celsius_temperature):
    """Return 'cold', 'mild', or 'hot'.

    Use these rules:
    - cold: below 10 degrees Celsius
    - mild: from 10 to 29 degrees Celsius
    - hot: 30 degrees Celsius or above

    >>> classify_temperature(5)
    'cold'
    >>> classify_temperature(20)
    'mild'
    >>> classify_temperature(35)
    'hot'
    """
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)
