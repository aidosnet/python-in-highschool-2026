"""Exercise: plan and draw recursive squares."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"


def square_sizes(start_size, count, step):
    """Return the square sizes produced by a recursive drawing.

    >>> square_sizes(100, 4, 10)
    [100, 90, 80, 70]
    >>> square_sizes(50, 0, 5)
    []
    """
    pass


def draw_centered_square(drawer, size):
    """Draw one square centered on the Turtle origin."""
    half_size = size / 2
    drawer.penup()
    drawer.goto(-half_size, -half_size)
    drawer.pendown()

    for _ in range(4):
        drawer.forward(size)
        drawer.left(90)

    drawer.penup()


def draw_recursive_squares(drawer, start_size, count, step):
    """Draw the square sizes produced by square_sizes."""
    for size in square_sizes(start_size, count, step):
        draw_centered_square(drawer, size)
        drawer.left(8)


def main():
    """Open a Turtle window and draw recursive squares."""
    import turtle

    screen = turtle.Screen()
    screen.setup(640, 640)
    screen.title("Recursive squares")
    screen.bgcolor("white")

    drawer = turtle.Turtle(visible=False)
    drawer.speed(0)
    drawer.color("darkgreen")
    drawer.pensize(2)

    draw_recursive_squares(drawer, 260, 18, 12)
    screen.mainloop()


if __name__ == "__main__":
    import doctest

    test_result = doctest.testmod(verbose=True)
    if test_result.failed == 0:
        main()
