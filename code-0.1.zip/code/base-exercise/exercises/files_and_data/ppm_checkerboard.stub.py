"""Exercise: create a PBM checkerboard image."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"


def checkerboard(width, height):
    """Return the body rows of a PBM P1 checkerboard image.

    >>> checkerboard(4, 3)
    ['0 1 0 1', '1 0 1 0', '0 1 0 1']
    """
    pass


def pbm_image(width, height):
    """Return a complete PBM P1 image as a string."""
    pass
