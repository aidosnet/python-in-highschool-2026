"""Exercise: count words in a text file."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"


def count_words(filename):
    """Return the number of words in filename.

    Words are separated by whitespace.
    """
    pass


def most_common_word(filename):
    """Return the most common word in filename.

    Compare words in lowercase. If the file is empty, return None.
    """
    pass
