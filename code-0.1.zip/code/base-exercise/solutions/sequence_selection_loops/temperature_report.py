"""Solution: convert Celsius temperatures and classify the result."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"


def convert_celsius(celsius_temperature):
    """Return Fahrenheit and Kelvin temperatures."""
    fahrenheit_temperature = celsius_temperature * 1.8 + 32
    kelvin_temperature = celsius_temperature + 273.15
    return fahrenheit_temperature, kelvin_temperature


def classify_temperature(celsius_temperature):
    """Return 'cold', 'mild', or 'hot'."""
    if celsius_temperature < 10:
        return "cold"
    if celsius_temperature < 30:
        return "mild"
    return "hot"


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)
