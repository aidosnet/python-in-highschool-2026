"""Solution: sum natural numbers with a loop."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"


def natural_sum(limit):
    """Return the sum of natural numbers from 1 to limit."""
    total = 0

    for current_number in range(1, limit + 1):
        total += current_number

    return total


def gauss_sum(limit):
    """Return the same sum using Gauss's formula."""
    return limit * (limit + 1) // 2


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)
