"""Solution: animate a bouncing ball."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"


def update_ball(x, y, speed_x, speed_y, min_x, max_x, min_y, max_y):
    """Return the updated ball state after one step.

    >>> update_ball(5, 5, 2, 3, 0, 10, 0, 10)
    (7, 8, 2, 3)
    >>> update_ball(9, 5, 2, 3, 0, 10, 0, 10)
    (11, 8, -2, 3)
    """
    x += speed_x
    y += speed_y

    if x < min_x or x > max_x:
        speed_x = -speed_x

    if y < min_y or y > max_y:
        speed_y = -speed_y

    return x, y, speed_x, speed_y


def draw_bounds(drawer, min_x, max_x, min_y, max_y):
    """Draw the rectangle where the ball bounces."""
    drawer.penup()
    drawer.goto(min_x, min_y)
    drawer.pendown()

    for x, y in (
        (max_x, min_y),
        (max_x, max_y),
        (min_x, max_y),
        (min_x, min_y),
    ):
        drawer.goto(x, y)

    drawer.penup()


def main():
    """Open a Turtle window and animate the bouncing ball."""
    import turtle

    min_x = -280
    max_x = 280
    min_y = -190
    max_y = 190
    x = 0
    y = 0
    speed_x = 4
    speed_y = 3

    screen = turtle.Screen()
    screen.setup(640, 480)
    screen.title("Bouncing ball")
    screen.bgcolor("white")
    screen.tracer(0)

    border = turtle.Turtle(visible=False)
    border.color("gray30")
    border.pensize(2)
    draw_bounds(border, min_x, max_x, min_y, max_y)

    ball = turtle.Turtle("circle")
    ball.color("dodgerblue")
    ball.penup()
    ball.shapesize(1.5)

    def animate():
        nonlocal x, y, speed_x, speed_y
        x, y, speed_x, speed_y = update_ball(
            x, y, speed_x, speed_y, min_x, max_x, min_y, max_y
        )
        ball.goto(x, y)
        screen.update()
        screen.ontimer(animate, 16)

    animate()
    screen.mainloop()


if __name__ == "__main__":
    main()
