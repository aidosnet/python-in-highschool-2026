"""Solution: create a PBM checkerboard image."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"


def checkerboard(width, height):
    """Return the body rows of a PBM P1 checkerboard image."""
    rows = []

    for row in range(height):
        values = []

        for column in range(width):
            values.append(str((row + column) % 2))

        rows.append(" ".join(values))

    return rows


def pbm_image(width, height):
    """Return a complete PBM P1 image as a string."""
    header = ["P1", f"{width} {height}"]
    return "\n".join(header + checkerboard(width, height)) + "\n"
