"""Solution: count words in a text file."""

from collections import Counter

__author__ = "maurizio.boscaini@marconiverona.edu.it"


def read_words(filename):
    """Return lowercase words from filename."""
    with open(filename, encoding="utf-8") as text_file:
        return text_file.read().lower().split()


def count_words(filename):
    """Return the number of words in filename."""
    return len(read_words(filename))


def most_common_word(filename):
    """Return the most common word in filename."""
    words = read_words(filename)

    if not words:
        return None

    return Counter(words).most_common(1)[0][0]
