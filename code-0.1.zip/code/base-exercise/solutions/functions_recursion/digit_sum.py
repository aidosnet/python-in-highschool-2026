"""Solution: use recursion to sum the digits of an integer."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"


def digit_sum(number):
    """Return the sum of the digits of number."""
    number = abs(number)

    if number < 10:
        return number

    return number % 10 + digit_sum(number // 10)


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)
