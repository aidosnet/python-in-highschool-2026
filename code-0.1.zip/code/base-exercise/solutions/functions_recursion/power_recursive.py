"""Solution: calculate powers using recursion."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"


def power(base, exponent):
    """Return base raised to exponent."""
    if exponent == 0:
        return 1

    return base * power(base, exponent - 1)


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)
