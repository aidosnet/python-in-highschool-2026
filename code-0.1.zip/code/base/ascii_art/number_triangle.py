"""Print a number triangle with the given number of rows.

1
12
123
1234
12345
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "0.1 2020-12-11"


row_count = int(input("Rows? "))

for row in range(1, row_count + 1):
    for number in range(1, row + 1):
        print(number, end="")
    
    print()


