"""Print an ASCII art rectangle using for loops.

*****
*****
*****
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "0.1 2018-11-21"

width = int(input("Width: "))
height = int(input("Height: "))
char = input("Character: ")

for row in range(height):
    for column in range(width):
        print(char, end="")
    print()

print()

for _ in range(height):
    print(char * width)
