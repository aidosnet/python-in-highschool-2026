"""Print an ASCII art right triangle using for loops.

Height: 4
Character: *
*
**
***
****
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "0.1 2020-11-30"

height = int(input("Height: "))
char = input("Character: ")

for row in range(height):
    for column in range(row + 1):
        print(char, end="")

    print()

for row in range(height):
    print(char * (row + 1))

triangle = ""

for row in range(height):
    triangle += char * (row + 1) + "\n"

print(triangle)
