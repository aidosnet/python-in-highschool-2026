"""Print an ASCII art diamond."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "0.1 2018-11-21"

char = input("Character: ")
height = int(input("Height: "))

for row in range(height):
    spaces = " " * (height - row - 1)
    symbols = char * (2 * row + 1)
    print(spaces + symbols)

for row in range(height - 2, -1, -1):
    spaces = " " * (height - row - 1)
    symbols = char * (2 * row + 1)
    print(spaces + symbols)
