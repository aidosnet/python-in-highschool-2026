"""Print a multiplication table from 1 to a user-provided limit."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "0.1 2018-11-21"

limit = int(input("Number: "))

for row in range(1, limit + 1):
    for column in range(1, 11):
        print(row * column, end="\t")

    print()
    
