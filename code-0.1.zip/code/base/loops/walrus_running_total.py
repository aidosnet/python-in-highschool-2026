"""Compare running totals with and without the walrus operator."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

# Totals without the walrus operator.
total = 0
value = float(input("? "))

while value != 0:
    total += value
    value = float(input("? "))

print(f"Sum: {total}")

# Totals with the walrus operator.
total = 0

while (value := float(input("? "))) != 0:
    total += value

print(f"Sum: {total}")
