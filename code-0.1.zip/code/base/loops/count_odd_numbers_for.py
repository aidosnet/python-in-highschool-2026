"""Print odd numbers from 1 to a user-provided limit using a for loop."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2021-12-10"

limit = int(input("Number? "))

for current_number in range(1, limit + 1, 2):
    print(current_number)
