"""Print the numbers from 1 to a user-provided limit using a while loop."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2021-12-10"

limit = int(input("Number? "))
current_number = 1

while current_number <= limit:
    print(current_number)
    current_number += 1

print("Done")
