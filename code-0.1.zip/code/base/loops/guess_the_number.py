"""Guess the secret number within a fixed number of attempts."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2025-11-07"

MAX_ATTEMPTS = 5

secret_number = 7
has_guessed = False
attempt_count = 0

print("Guess the secret number (between 1 and 100)!")

while not has_guessed and attempt_count < MAX_ATTEMPTS:
    guess = int(input("Enter a number: "))
    attempt_count += 1

    if guess < secret_number:
        print("Too low! Try again.")
    elif guess > secret_number:
        print("Too high! Try again.")
    else:
        has_guessed = True


if has_guessed:
    print("Good job! You guessed it!")
else:
    print("Sorry, try again!")
