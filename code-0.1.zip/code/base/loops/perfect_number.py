"""Check whether a number is perfect using a for loop."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2024-11-13"

# Input
number = int(input("Number? "))

# Processing
divisor_sum = 0

for divisor in range(1, number):
    if number % divisor == 0:
        divisor_sum += divisor

# Output
if divisor_sum == number:
    print(number, "is perfect")
else:
    print(number, "is not perfect")
