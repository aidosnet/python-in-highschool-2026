"""Compare a loop with and without the walrus operator."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

# Totals without the walrus operator.
numbers = [1, 2, 3, 4, 5]
item_count = len(numbers)

while item_count > 0:
    print(numbers.pop(), end=", ")
    item_count = len(numbers)
    print("Remaining items:", item_count)

print("\n")

# Totals with the walrus operator.
numbers = [1, 2, 3, 4, 5]

while (item_count := len(numbers)) > 0:
    print(numbers.pop(), end=", ")
    print("Remaining items:", item_count - 1)

