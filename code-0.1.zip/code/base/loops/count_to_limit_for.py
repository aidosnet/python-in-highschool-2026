"""Print the numbers from 1 to a limit using a for loop."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2021-12-10"

limit = 10  # int(input("Number? "))

for current_number in range(1, limit + 1):
    print(current_number, end=" ")

print("Done")
