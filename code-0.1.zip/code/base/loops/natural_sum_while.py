"""Sum the first natural numbers using a while loop and Gauss's formula."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2021-12-10"

limit = int(input("Number? "))

current_number = 1
result = 0

while current_number <= limit:
    result += current_number
    current_number += 1

print("Calculated sum:", result)
print("Formula sum:", (limit + 1) * limit // 2)
