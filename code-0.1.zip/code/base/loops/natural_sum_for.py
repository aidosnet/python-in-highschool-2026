"""Sum the first natural numbers using a for loop and Gauss's formula."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2021-12-10"

limit = int(input("Number? "))
result = 0

for current_number in range(1, limit + 1):
    result += current_number

print("Calculated sum:", result)
print("Formula sum:", (limit + 1) * limit // 2)
