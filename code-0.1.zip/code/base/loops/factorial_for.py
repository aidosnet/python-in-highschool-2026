"""Calculate the factorial of a positive integer using a for loop."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2025-11-05"

number = int(input("Number? "))
factorial = 1

for factor in range(1, number + 1):
    factorial *= factor

print("Factorial of ", number, ": ", factorial, sep="")
