"""Calculate the factorial of a positive integer using a while loop."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2025-11-05"

number = int(input("Number? "))
factor = 1
factorial = 1

while factor <= number:
    factorial *= factor
    factor += 1

print("Factorial of ", number, ": ", factorial, sep="")
