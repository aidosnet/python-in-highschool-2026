"""Programma per la visualizzazione di file PPM P3"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

import turtle

__version__ = "0.3"


def draw_pixel(x, y, color, scale=1, mode="default"):
    """Draw a colored pixel at (x, y), optionally scaled."""
    turtle.up()
    turtle.goto(x * scale, -y * scale)
    turtle.down()

    if mode == "grey":
        # Scala di grigi
        r = g = b = (color[0] + color[1] + color[2]) // 3
        color = (r, g, b)
    elif mode == "blue":
        # Scala di rossi
        average = (color[0] + color[1] + color[2]) // 3
        b = min(average, 255)
        if b == 255:
            color = (255, 255, 255)
        else:
            color = (0, 0, b)

    turtle.dot(scale, color)
    turtle.up()


def ppm_metadata(filename):
    """Return the metadata of a Netpbm P3 image."""
    file = open(filename)
    lines = file.readlines()
    ppm_type = lines[0][:-1]  # P3
    size = lines[2].split()
    w = int(size[0])
    h = int(size[1])
    ppm_colormode = int(lines[3])
    file.close()
    return ppm_type, w, h, ppm_colormode


def draw_ppm(filename, scale=1, mode="default"):
    """Draw a PPM file on the canvas using a scale factor >= 1. If scale is 1, the drawing has the same scale as the original image."""
    turtle.hideturtle()
    turtle.tracer(0)
    ppm_type, w, h, ppm_colormode = ppm_metadata(filename)
    turtle.colormode(ppm_colormode)
    file = open(filename)
    lines = file.readlines()[4:]

    for i in range(0, len(lines), 3):
        r = int(lines[i + 0])
        g = int(lines[i + 1])
        b = int(lines[i + 2])
        x = (i // 3) % w - w // 2  # ...traslo
        y = (i // 3) // w - h // 2  # ...traslo
        draw_pixel(x, y, (r, g, b), scale, mode)

    file.close()
    print(w, h)
    turtle.update()


if __name__ == "__main__":
    draw_ppm("data/anime.ppm", scale=4, mode="blue")
    turtle.mainloop()
