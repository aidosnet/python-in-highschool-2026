"""PPM File
https://en.wikipedia.org/wiki/Netpbm
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2020-03-21"

from random import randint

def create_ppm(filename, width, height, step):
    """Createte a width x height PPM P3 image with random-colored horizontal lines of height step.
    """
    magic_number = "P3"
    max_color = 255    
    header = f"{magic_number}\n{width} {height}\n{max_color}\n"
    
    # Data
    # Costruisco la linea orizzontale con segmenti lunghi step di vari colori
    data = ""
    count = 0
    
    while count < height:
        r = randint(0, 255)
        g = randint(0, 255)
        b = randint(0, 255)
        h_remaining = height - (count // step) * step
        h_row = min(step, h_remaining)
        data += f"{r} {g} {b}\n" * (width * h_row)
        count += step
                
    with open(filename, "w") as file:
        file.write(header)
        file.write(data)

if __name__ == "__main__":
    filename = "random_hlines3.ppm"
    create_ppm(filename, 40, 10, 3)
