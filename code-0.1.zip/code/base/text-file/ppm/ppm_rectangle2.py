"""PPM File
https://en.wikipedia.org/wiki/Netpbm
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2021-05-05"

def create_ppm(filename, width, height, r, g, b):
    """Createte a sample PPM file: a width x height rectangle with pixels of color (r, g, b).
    """
    magic_number = "P3"
    max_color = 255
    
    header = f"{magic_number}\n{width} {height}\n{max_color}\n"
    
    # Data
    data = ""

    for i in range(height):
        for j in range(width):
            data += f"{r} {g} {b}\n"
            
    with open(filename, "w", encoding="utf-8") as file:
        file.write(header + data)

if __name__ == "__main__":
    filename = "rectangle2.ppm"
    create_ppm(filename, width=200, height=120, r=200, g=100, b=260)
    
    

