__author__ = "maurizio.boscaini@marconiverona.edu.it"

def pbm_p1_horizontal_lines1(width: int, height: int) -> str:
    """Return a text representation of a PBM P1 image
    with horizontal black-and-white lines of size width x height."""
    header: str = f"P1\n{width} {height}\n"
    data: str = ""

    for i in range(height):
        color: str = "1 " if i % 2 == 0 else "0 "
        data += color * width

    return header + data


if __name__ == "__main__":
    filename: str = "output/horizontal_lines1.pbm"
    content: str = pbm_p1_horizontal_lines1(10, 6)

    with open(filename, mode="w", encoding="UTF-8") as f:
        f.write(content)
