__author__ = "maurizio.boscaini@marconiverona.edu.it"

def pbm_p1_black_rect1(width: int, height: int) -> str:
    """Return a text representation of a PBM P1 image
    with black pixels of size width x height."""
    header: str = f"P1\n{width} {height}\n"
    data: str = "1 " * (width * height)  # Lo spazio (ovvero il separatore) non serve

    return header + data


def pbm_p1_black_rect2(width: int, height: int) -> str:
    """Return a text representation of a PBM P1 image
    with black pixels of size width x height."""
    header: str = f"P1\n{width} {height}\n"
    data: str = ""

    for i in range(height):
        for j in range(width):
            data += "1 "

    return header + data


def pbm_p1_black_rect3(width: int, height: int) -> str:
    """Return a text representation of a PBM P1 image
    with black pixels of size width x height."""
    header: str = f"P1\n{width} {height}\n"
    data: str = ""

    for _ in range(height * width):
        data += "1 "

    return header + data


if __name__ == "__main__":
    width: int = 30
    height: int = 20
    filename: str = f"output/black_rect{width}x{height}.pbm"
    content: str = pbm_p1_black_rect1(width, height)
    # content = pbm_p1_black_rect2(width, height)

    with open(filename, mode="w", encoding="utf-8") as f:
        f.write(content)
