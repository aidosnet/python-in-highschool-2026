"""PPM File: Portable PixMap (P3)
https://en.wikipedia.org/wiki/Netpbm
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2021-05-07"

from random import randint

def create_ppm(filename, size, quadSize, color1, color2):
    """Createte a size x size checkerboard PPM P3 image.
    con squares di dimensione quadSize    
    """
    # Header
    magic_number = "P3"
    max_color = 255  
    header = f"{magic_number}\n{size} {size}\n{max_color}\n"
    
    # Data
    # Costruisco la linea orizzontale con segmenti lunghi step di vari colori
    data = ""
    rows = cols = size // quadSize
    
    for row in range(rows):
        line = ""
        
        for col in range(cols):
            # if (row % 2 == 0 and col % 2 == 0) or (row % 2 == 1 and col % 2 == 1)
            # if row % 2 == col % 2:
            r, g, b = color1 if (row + col) % 2 == 0 else color2            
            line += f"{r} {g} {b}\n" * quadSize                
            
        data += line * quadSize

    with open(filename, "w") as file:  # Apertura file in scrittura ("write")
        file.write(header + data)

if __name__ == "__main__":
    filename = "quads2b.ppm"
    create_ppm(filename, 400, 50, (255, 255, 255), (0, 0, 0))
