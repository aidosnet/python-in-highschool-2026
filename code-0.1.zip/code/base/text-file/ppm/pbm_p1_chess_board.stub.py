__author__ = "maurizio.boscaini@marconiverona.edu.it"

def pbm_p1_chess_board1(width: int, height: int) -> str:
    """Return a text representation of a PBM P1 image
    with a black-and-white chessboard of size width x height."""
    # TODO


if __name__ == "__main__":
    width: int = 30
    height: int = 20
    filename: str = f"output/chess{width}x{height}.pbm"
    content: str = pbm_p1_chess_board1(width, height)

    with open(filename, mode="w", encoding="UTF-8") as f:
        f.write(content)
