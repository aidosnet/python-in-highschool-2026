"""PPM File
https://en.wikipedia.org/wiki/Netpbm
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2026-05-11"


def txt_to_ppm(filename_txt: str, filename_ppm: str):
    """Createte a black and white width x height PPM P3 image
    salvandola in filename_ppm
    con i dati presenti nel file filename_txt.
    Le prime righe del file sono riportate di seguito:
    10111000000001010000100011111101000100010001101110
    01011110111100000010110100110110001001001111100000
    11100010100001001101100101100000111001000110110000
    ...
    """
    with open(filename_txt, encoding="utf-8") as file:
        lines = file.readlines()

    width: int = len(lines[0]) - 1
    height: int = len(lines)
    magic_number: str = "P3"

    header: str = f"{magic_number}\n{width} {height}\n255\n"
    data: str = ""

    for line in lines:
        data += line.replace("0", "255 255 255 ").replace("1", "0 0 0 ")

    with open(filename_ppm, "w", encoding="utf-8") as file:
        file.write(header + data)


if __name__ == "__main__":
    filename_txt: str = "data/magilla_gorilla_800x600.txt"
    filename_ppm: str = filename_txt.replace(".txt", ".ppm")
    txt_to_ppm(filename_txt, filename_ppm)
