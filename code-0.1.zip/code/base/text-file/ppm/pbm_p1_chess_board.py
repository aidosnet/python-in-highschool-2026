__author__ = "maurizio.boscaini@marconiverona.edu.it"

def pbm_p1_chess_board1(width: int, height: int) -> str:
    """Return a text representation of a PBM P1 image
    with a black-and-white chessboard of size width x height."""
    header: str = f"P1\n{width} {height}\n"
    data: str = ""

    for i in range(height):
        for j in range(width):
            if (i + j) % 2 == 0:
                data += "1 "
            else:
                data += "0 "

    return header + data


def pbm_p1_chess_board2(width: int, height: int) -> str:
    """Return a text representation of a PBM P1 image
    with a black-and-white chessboard of size width x height."""
    header: str = f"P1\n{width} {height}\n"
    data: str = ""

    for i in range(height):
        for j in range(width):
            data += "1 " if (i + j) % 2 else "0 "

    return header + data


def pbm_p1_chess_board3(width: int, height: int) -> str:
    """Return a text representation of a PBM P1 image
    with a black-and-white chessboard of size width x height."""
    header = f"P1\n{width} {height}\n"
    data = ""

    for i in range(height // 2):  # On each passage add two lines
        for j in range(width):
            data += "1 " if (i * 2 + j) % 2 == 0 else "0 "

        for j in range(width):
            data += "0 " if (i * 2 + j) % 2 == 0 else "1 "

    # If the number of row is odd, add another line like the first one
    if height % 2 == 1:
        for j in range(width):
            data += "1 " if (i + j) % 2 else "0 "

    return header + data


if __name__ == "__main__":
    width: int = 30
    height: int = 20
    filename: str = f"output/chess{width}x{height}.pbm"
    content: str = pbm_p1_chess_board3(width, height)

    with open(filename, mode="w", encoding="UTF-8") as f:
        f.write(content)
