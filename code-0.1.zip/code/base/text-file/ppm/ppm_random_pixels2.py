"""PPM File
https://en.wikipedia.org/wiki/Netpbm
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "2.0 2021-05-05"

from random import randint

def create_ppm(filename, width, height, n, bgcolor, fgcolor):
    """Createte a width x height PPM P3 image with n random lit pixels.
    """
    magic_number = "P3"
    max_color = 255    
    header = f"{magic_number}\n{width} {height}\n{max_color}\n"
    
    npixels = width * height  # Calculate the product only once
    
    # 1. list comprehension (potrebbe accedere meno pixel di quelli richiesti)
    # positions = [randint(0, npixels - 1) for _ in range(step_count)]
    
    # 2. list
    positions = []
    i = 0
    while i < n:
        index = randint(0, npixels - 1)
        
        if not index in positions:
            positions.append(index)
            i += 1
        
    # Data
    data = ""
    for i in range(height):
        for j in range(width):
            color = fgcolor if (i * width) + j in positions else bgcolor
            r, g, b = color
            data += f"{r} {g} {b}\n"
            
    with open(filename, "w") as file:
        file.write(header)
        file.write(data)

if __name__ == "__main__":
    filename = "random_pixels2.ppm"
    create_ppm(filename, 400, 300, 2000, (0, 0, 0), (255, 255, 0))
