__author__ = "maurizio.boscaini@marconiverona.edu.it"

def html_list(filename, level1_mark="#"):
    """Createte HTML code with a list and a nested list,
    utilizzando level1_mark come marcatore del primo livello.
    """
    html = ""

    for line in open(filename, encoding="utf-8"):
        if line[0] == level1_mark:
            # Marcatore
            if html == "":
                html += "<ul>"
                html += f"<li>{line[1:-1]}</li>\n<ul>\n"
            else:
                html += "</ul>\n<ul>"
                html += f"</ul>\n<li>{line[1:-1]}</li>\n<ul>\n"
        else:
            html += f"<li>{line[:-1]}</li>\n"

    html += "</ul>"
    return html


def save_html(filename, template_filename, title, body):
    """Createte an HTML file from the provided template and body code."""
    html = open(template_filename, encoding="utf-8").read()
    html = html.replace("<% title %>", title)
    html = html.replace("<% body %>", body)
    file = open(filename, encoding="utf-8", mode="w")
    file.write(html)
    file.close()


if __name__ == "__main__":
    data_filename = "./data/cs_legends.txt"
    template_filename = "./assets/template/page_template.html"
    title = "Computer Science Legends 1"
    body = html_list(data_filename)
    save_html(
        "cs_legends2.html",
        template_filename,
        title,
        body,
    )
