"""
Legge un file di CSV con i valori di altezza e peso e crea un file HTML
con la tabella in cui, oltre all'altezza e al peso, viene aggiunta
la colonna con l'indice di massa corporeo (body mass index) (BMI) con la formula:
BMI = peso (in kg) / altezza (in metri) al quadrato
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

def html_render(title, content):
    """Genera un HTML di base con titolo e contenuto."""
    # TODO


def save_text_file(filename, text):
    """Salva il testo in un file con il nome specificato."""
    # TODO


def csv2html(filename, sep=","):
    """Legge un file CSV con sep come separatore tra i campi con i valori di altezza e peso e crea un file HTML"""
    # TODO


if __name__ == "__main__":
    filename = "data/bmi.csv"
    html = csv2html(filename)
    save_text_file(filename + ".html", html)
    print(f"File HTML {filename +'.html'} creato con successo!")
