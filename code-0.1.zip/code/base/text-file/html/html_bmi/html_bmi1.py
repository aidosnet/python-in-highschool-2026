"""
Legge un file di CSV con i valori di altezza e peso e crea un file HTML
con la tabella in cui, oltre all'altezza e al peso, viene aggiunta
la colonna con l'indice di massa corporeo (body mass index) (BMI) con la formula:
BMI = peso (in kg) / altezza (in metri) al quadrato
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

def html_render(title: str, content: str) -> str:
    """Genera un HTML di base con titolo e contenuto."""
    return f"""
    <!DOCTYPE html>
    <html>
        <head>
            <title>{title}</title>
        </head>
        <body>
            {content}
        </body>
    </html>
    """


def save_text_file(filename, text):
    """Salva il testo in un file con il nome specificato."""
    with open(filename, mode="w", encoding="utf-8") as file:  # Open the file in write mode and specify UTF-8 encoding
        file.write(text)


def csv2html(filename, sep=","):
    """Legge un file CSV con sep come separatore tra i campi con i valori di altezza e peso e crea un file HTML"""
    html_table = "<table border='1'>"
    html_table += "<tr><th>Altezza (m)</th><th>Peso (kg)</th><th>BMI</th></tr>\n"  # Aggiunge l'intestazione della tabella con i nomi delle colonne
    first_line = True

    with open(filename, "r", encoding="utf-8") as file:
        for line in file:
            if first_line:
                first_line = False
            else:
                values = line.strip().split(sep)
                height = float(values[0])
                weight = float(values[1])
                bmi = weight / (height * height)  # Calculate BMI
                # Aggiunge una riga alla tabella con i valori di altezza, peso e BMI
                html_table += f"<tr><td>{height}</td><td>{weight}</td><td>{bmi:.2f}</td></tr>\n"

    html_table += "</table>"
    return html_table


if __name__ == "__main__":
    filename = "data/bmi.csv"
    html = csv2html(filename)
    save_text_file(filename + ".html", html)
    print(f"File HTML {filename +'.html'} creato con successo!")
