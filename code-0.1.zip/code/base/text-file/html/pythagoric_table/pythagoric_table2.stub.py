__author__ = "maurizio.boscaini@marconiverona.edu.it"

def is_prime(n):
    """Verifica se n è primo, oppure no."""


def html_pythagoric_table(n):
    """Restituisce una stringa con una tabella HTML con la tavola pitagorica
    fino ad n"""


def write_html_document(body, filename):
    """Scrive in un file un documento HTML"""


if __name__ == "__main__":
    body = html_pythagoric_table(10)
    filename = "pythagoric_table2.html"
    write_html_document(body, filename)
    print(filename, "created!")
