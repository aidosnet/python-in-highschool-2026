__author__ = "maurizio.boscaini@marconiverona.edu.it"

def is_prime(n):
    """Verifica se n è primo, oppure no."""
    for i in range(2, n // 2 + 1):
        if n % i == 0:
            return False

    return n > 1


def html_pythagoric_table(n):
    """Restituisce una stringa con una tabella HTML con la tavola pitagorica
    fino ad n"""
    html = "<table>"
    html += "<tr>\n"

    for i in range(1, n + 1):
        html += f"\t<th>x {i}</th>\n"
    html += "</tr>\n"

    for i in range(1, n + 1):
        html += "<tr>\n"

        for j in range(1, n + 1):
            if is_prime(i * j):
                html += f"\t<td class='prime'> {i*j} </td>\n"
            else:
                html += f"\t<td>{i*j}</td>\n"

        html += "</tr>\n"

    html += "</table>"
    return html


def write_html_document(body, filename):
    """Scrive in un file un documento HTML"""
    html = f"""
<!DOCTYPE html>
<html>
    <head>
        <title>Tabellina pitagorica</title>
        <link rel="stylesheet" type="text/css" href="css/styles.css">
    </head>
    <body>
        <h1>Tabella pitagorica</h1>
        {body}
    </body>
</html>
    """
    # Modo 1
    file = open(filename, "w", encoding="utf-8")
    file.write(html)
    file.close()

    # Modo 2
    with open(filename, "w", encoding="utf-8") as file:
        file.write(html)


if __name__ == "__main__":
    body = html_pythagoric_table(10)
    filename = "pythagoric_table2.html"
    write_html_document(body, filename)
    print(filename, "created!")
