"""
Legge un file di testo e crea un HTML che mantenga la formattazione dei paragrafi.
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

def html_render(title, content):
    """Genera un HTML di base con titolo e contenuto."""
    # TODO


def txt2html(filename, words_to_mark=[]):
    """Legge un file di testo e crea un HTML che mantenga la formattazione dei paragrafi.
    Inoltre, evidenzia le parole specificate in words_to_mark con il tag <mark>.
    """
    # TODO


def save_text_file(filename, text):
    """Salva il testo in un file con il nome specificato."""
    # TODO


if __name__ == "__main__":
    filename = "data/divina.txt"
    html = txt2html(filename, ["del", "vita"])
    save_text_file(filename + ".html", html)
    print(f"File HTML {filename +'.html'} creato con successo!")
