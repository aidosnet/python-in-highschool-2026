"""
Legge un file di testo e crea un HTML che mantenga la formattazione dei paragrafi.
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

def html_render(title, content):
    """Genera un HTML di base con titolo e contenuto."""
    return f"""
    <!DOCTYPE html>
    <html>
        <head>
            <title>{title}</title>
        </head>
        <body>
            {content}
        </body>
    </html>
    """


def txt2html(filename, words_to_mark=[]):
    """Legge un file di testo e crea un HTML che mantenga la formattazione dei paragrafi.
    Inoltre, evidenzia le parole specificate in words_to_mark con il tag <mark>.
    """
    text = open(filename, "r", encoding="utf-8").read()  # Legge l'intero contenuto del file di testo
    text = text.replace("\n", "<br />\n")  # Sostituisce i ritorni a capo con <br />

    for word in words_to_mark:  # Per ogni parola da evidenziare
        text = text.replace(word, f"<mark>{word}</mark> ")  # Sostituisce la parola con la versione evidenziata

    return html_render("Render HTML", text)  # Restituisce l'HTML completo con titolo e contenuto formattato


def save_text_file(filename, text):
    """Salva il testo in un file con il nome specificato."""
    with open(filename, "w", encoding="utf-8") as file:  # Open the file in write mode and specify UTF-8 encoding
        file.write(text)


if __name__ == "__main__":
    filename = "data/divina.txt"
    html = txt2html(filename, ["del", "vita"])
    save_text_file(filename + ".html", html)
    print(f"File HTML {filename +'.html'} creato con successo!")
