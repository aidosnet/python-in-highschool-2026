__author__ = "maurizio.boscaini@marconiverona.edu.it"

from random import randint


def svg_random_circles(n: int, width: int, height: int) -> str:
    """Restituisce un parte di documento SVG con n circles random"""
    svg = ""

    for _ in range(step_count):
        cx = randint(0, width - 1)
        cy = randint(0, height - 1)
        radius = randint(1, 20)
        r = randint(0, 255)
        g = randint(0, 255)
        b = randint(0, 255)
        svg += f'<circle cx="{cx}" cy="{cy}" r="{radius}" stroke-width="2" stroke="black" fill="rgb({r}, {g}, {b})" />\n'

    return svg


def save_svg_document1(filename: str, width: int, height: int, body: str) -> None:
    """Scrive in un file un documento SVG"""
    svg_start = f"""<?xml version="1.0"?>
        <svg width="{width}" height="{height}" xmlns="http://www.w3.org/2000/svg">
    """
    svg_end = "</svg>"

    with open(filename, mode="w", encoding="utf-8") as file:
        file.write(svg_start + body + svg_end)


def save_svg_document2(filename: str, width: int, height: int, body: str):
    """Scrive in un file un documento SVG"""
    content = f"""<?xml version="1.0"?>
        <svg width="{width}" height="{height}" xmlns="http://www.w3.org/2000/svg">
        {body}
        </svg>
    """

    with open(filename, mode="w", encoding="utf-8") as file:
        file.write(content)


if __name__ == "__main__":
    width, height = 800, 600
    body: str = svg_random_circles(100, width, height)
    save_svg_document2("random_circles1.svg", width, height, body)
