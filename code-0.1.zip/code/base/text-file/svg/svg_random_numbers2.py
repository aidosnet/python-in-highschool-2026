__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "1.0 2022-06-04"

from random import randint

if __name__ == "__main__":
    width = 800
    height = 450

    svg_head = f"""<?xml version=\"1.0\"?>
<svg
    width=\"{width}\" height=\"{height}\"
    xmlns=\"http://www.w3.org/2000/svg\"
    xmlns:svg=\"http://www.w3.org/2000/svg\">
"""
    svg_body = f"\t<rect width=\"{width}\" height=\"{height}\" fill=\"black\"/>"
    svg_end = "</svg>"
    
    _x = 0
    
    while _x < width:
        x = _x + randint(0, 16)
        y = randint(-20, 0)

        while y < height:
            r = randint(28, 75)
            g = randint(93, 247)
            b = randint(31, 85)
            number = randint(0, 9)
            alpha = randint(-30, 30)
            svg_body += f"\t<text x=\"{x}\" y=\"{y}\" fill=\"rgb({r},{g},{b})\" transform=\"rotate({alpha}, {x}, {y})\">{number}</text>\n"
            y += randint(10, 30)

        _x += randint(10, 20)

    with open("matrix.svg", "w") as file:
        file.write(svg_head)
        file.write(svg_body)
        file.write(svg_end)
