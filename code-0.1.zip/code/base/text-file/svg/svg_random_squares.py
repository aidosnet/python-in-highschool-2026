__author__ = "maurizio.boscaini@marconiverona.edu.it"

import random


def svg_random_squares(n, width, height):
    """Restituisce un parte di documento SVG con n circles random"""
    svg = ""

    for _ in range(step_count):
        x = random.randint(0, width - 1)
        y = random.randint(0, height - 1)
        size = random.randint(5, 20)
        r = random.randint(0, 255)
        g = random.randint(0, 255)
        b = random.randint(0, 255)
        svg += f'\t\t\t<rect x="{x}" y="{y}" width="{size}" height="{size}" strokewidth="0" fill="rgb({r}, {g}, {b})" />\n'
    return svg


def write_svg_document(body, filename, width=800, height=600):
    """Scrive in un file un documento SVG"""
    svg_start = f"""<?xml version="1.0"?>
        <svg width="{width}" height="{height}" xmlns="http://www.w3.org/2000/svg">
    """
    svg_end = """
        </svg>
    """
    with open(filename, "w") as file:
        file.write(svg_start)
        file.write(body)
        file.write(svg_end)


if __name__ == "__main__":
    width, height = 800, 600
    body = svg_random_squares(1000, width, height)
    write_svg_document(body, "random_squares.svg", width, height)
