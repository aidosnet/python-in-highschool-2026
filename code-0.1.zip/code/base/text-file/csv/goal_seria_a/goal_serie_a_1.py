__author__ = "maurizio.boscaini@marconiverona.edu.it"

HOMETEAM_INDEX = 2
AWAYTEAM_INDEX = 3
FTHG_INDEX = 4
FTAG_INDEX = 5


def goals1(filename, squadra, sep=","):
    """Return the number of goals scored by a team both at home and away.<br>
    Tracciato record:<br>
    Div,Date,HomeTeam,AwayTeam,FTHG,FTAG,...
    """
    result = 0
    lines = open(filename, encoding="utf-8").readlines()[1:]

    for line in lines:
        values = line.strip().split(sep)

        # Home team
        if values[HOMETEAM_INDEX] == squadra:
            result += int(values[FTHG_INDEX])

        # Away team
        if values[AWAYTEAM_INDEX] == squadra:
            result += int(values[FTAG_INDEX])

    return result


def goals2(filename, squadra):
    """Return the number of goals scored by a team both at home and away.<br>
    Tracciato record:<br>
    Div,Date,HomeTeam,AwayTeam,FTHG,FTAG,...
    """
    result = 0
    first_line = True

    for line in open(filename, encoding="utf-8"):
        if first_line:
            first_line = False
        else:
            values = line.strip().split(",")

            # Home team
            if values[HOMETEAM_INDEX] == squadra:
                result += int(values[FTHG_INDEX])

            # Away team
            if values[AWAYTEAM_INDEX] == squadra:
                result += int(values[FTAG_INDEX])

    return result


if __name__ == "__main__":
    print(goals1("data/2016-2017.csv", "Juventus"))
