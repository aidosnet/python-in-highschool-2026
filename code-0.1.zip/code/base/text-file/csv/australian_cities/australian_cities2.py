__author__ = "maurizio.boscaini@marconiverona.edu.it"

def csv_to_html_table(filename, sep="\t"):
    """Createte HTML code with a table based on the data in the CSV file."""
    html = "<table>\n"
    first_line = True

    for line in open(filename, encoding="utf-8"):
        html += "\t<tr>\n"

        for value in line[:-1].split(sep):
            if first_line:
                html += f"\t\t<th>{value}</th>"
            else:
                html += f"\t\t<td>{value}</td>"

        if first_line:
            first_line = False
        html += "\t</tr>\n"

    html += "</table>\n"
    return html


def save_html(filename, template_filename, title, body):
    """Createte an HTML file from the provided template and body code."""
    html = open(template_filename, encoding="utf-8").read()
    html = html.replace("<% title %>", title)
    html = html.replace("<% body %>", body)
    file = open(filename, encoding="utf-8", mode="w")
    file.write(html)
    file.close()


if __name__ == "__main__":
    data_filename = "./data/australian_cities2.csv"
    template_filename = "./assets/template/page_template.html"
    title = "Australian cities 2"
    h1 = f"<h1>{title}</h1>"
    table = csv_to_html_table(data_filename)
    body = h1 + table
    save_html(
        "australian_cities2.html",
        template_filename,
        title,
        body,
    )
