__author__ = "maurizio.boscaini@marconiverona.edu.it"

                              
__version__ = "2024-03-22"


def read_my_file(filename):
    """Read a text file and count the number of words
    utilizzando lo spazio come separatore."""
    count = 0

    with open(filename) as file:
        for line in file:
            line = line.strip()
            
            if line:
                words = line.split()
                count += len(words)
    
    return count

if __name__ == "__main__":
    n = read_my_file(__file__)
    print(f"Numero di parole: {n}")
    
