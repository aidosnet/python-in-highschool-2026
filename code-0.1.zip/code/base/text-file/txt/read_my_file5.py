__author__ = "maurizio.boscaini@marconiverona.edu.it"

                              
__version__ = "2024-03-22"


def read_my_file(filename):
    """Legge un file di testo eseguendo una lettura linea per linea (readline())
    e stampa a video il contenuto di ogni riga."""
    lines = open(filename, encoding="utf-8", mode="rt").readlines()
    
    for line in lines:
        print(line.rstrip())

if __name__ == "__main__":
    read_my_file("data/il_bacio.txt")
