__author__ = "maurizio.boscaini@marconiverona.edu.it"

def read_my_file():
    """Print the contents of the current module file."""
    for line in open("read_my_file1.py", encoding="utf-8"):  # mode="rt"
        print(line, end="")  # ok
        # print(line.rstrip())  # ok
        # print(line[:-1])  # ok
        # print(line.strip())  # ko
        # print(line)  # ko
    print()


if __name__ == "__main__":
    read_my_file()
