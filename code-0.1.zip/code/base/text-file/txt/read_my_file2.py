__author__ = "maurizio.boscaini@marconiverona.edu.it"

def read_my_file():
    """Print the contents of the current module.
    Se il file non è presente o non si hanno i permessi di lettura,
    stampa "Error nell'apertura del file 'read_my_file2.py'" """
    filename = "read_my_file2.py"

    try:
        for line in open(filename, encoding="utf-8"):
            print(line, end="")
    except:
        print(f"Error nell'apertura del file '{filename}'")


if __name__ == "__main__":
    read_my_file()
