__author__ = "maurizio.boscaini@marconiverona.edu.it"

def read_my_file(filename=None):
    """Print the contents of a specified file or the current module,
    se non è specificato alcun file.
    Se il file non è presente o non si hanno i permessi di lettura,
    stampa "Error nell'apertura del file 'nome del file'" """
    if not filename:
        filename = __file__

    try:
        for line in open(filename, encoding="utf-8"):
            print(line, end="")

        print()
    except FileNotFoundError:  # Cattura solo l'eccezione specificata
        print(f"Error nell'apertura del file '{filename}'")


if __name__ == "__main__":
    read_my_file()
