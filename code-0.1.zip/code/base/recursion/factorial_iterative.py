__author__ = "maurizio.boscaini@marconiverona.edu.it"


def factorial(number):
    """Return the factorial of number using an iterative algorithm.

    >>> factorial(0)
    1
    >>> factorial(1)
    1
    >>> factorial(5)
    120
    """
    result = 1

    for factor in range(1, number + 1):
        result *= factor

    return result


if __name__ == "__main__":
    import doctest

    doctest.testmod()
