__author__ = "maurizio.boscaini@marconiverona.edu.it"


def fibonacci(index, cache=None):
    """Return the nth Fibonacci term using recursion with memoization.

    >>> fibonacci(0)
    1
    >>> fibonacci(1)
    1
    >>> fibonacci(10)
    89
    """
    if cache is None:
        cache = {}

    if index in cache:
        return cache[index]

    if index in (0, 1):
        return 1

    result = fibonacci(index - 1, cache) + fibonacci(index - 2, cache)
    cache[index] = result
    return result


if __name__ == "__main__":
    import doctest

    doctest.testmod()
    print(fibonacci(50))
