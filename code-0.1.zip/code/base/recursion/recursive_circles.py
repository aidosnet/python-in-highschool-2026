import turtle

__author__ = "maurizio.boscaini@marconiverona.edu.it"


def draw_circle(radius: int, count: int) -> None:
    """Draw recursive circles while count is greater than 0."""
    # assert radius > 0 and count >= 0, "Invalid values"

    if count <= 0:
        return

    ninja = turtle.Turtle()
    ninja.circle(radius, 360)

    draw_circle(radius - 5, count - 1)


if __name__ == "__main__":
    draw_circle(100, 10)
    turtle.Screen().exitonclick()
