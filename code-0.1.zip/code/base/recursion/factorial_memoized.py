__author__ = "maurizio.boscaini@marconiverona.edu.it"


def factorial(number, cache=None):
    """Return the factorial of number using recursion with memoization.

    >>> factorial(0)
    1
    >>> factorial(1)
    1
    >>> factorial(5)
    120
    """
    if cache is None:
        cache = {}

    if number in cache:
        return cache[number]

    if number == 0:
        return 1

    value = number * factorial(number - 1, cache)
    cache[number] = value
    return value


if __name__ == "__main__":
    import doctest

    doctest.testmod()
    factorial(4)
