__author__ = "maurizio.boscaini@marconiverona.edu.it"


def fibonacci(index):
    """Return the nth Fibonacci term using recursion.

    >>> fibonacci(0)
    1
    >>> fibonacci(1)
    1
    >>> fibonacci(10)
    89
    """
    if index in (0, 1):
        return 1

    return fibonacci(index - 1) + fibonacci(index - 2)


if __name__ == "__main__":
    import doctest

    doctest.testmod()
    print(fibonacci(40))
