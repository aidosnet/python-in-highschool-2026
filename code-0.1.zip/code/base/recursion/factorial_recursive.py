__author__ = "maurizio.boscaini@marconiverona.edu.it"


def factorial(number):
    """Return the factorial of number using recursion.

    >>> factorial(0)
    1
    >>> factorial(1)
    1
    >>> factorial(5)
    120
    """
    if number == 0:
        return 1

    return number * factorial(number - 1)


if __name__ == "__main__":
    import doctest

    doctest.testmod()
    print(factorial(1000))
