import turtle

__author__ = "maurizio.boscaini@marconiverona.edu.it"


def draw_square(size: int, count: int) -> None:
    """Draw recursive squares while count is greater than 0."""
    # assert size > 0 and count >= 0, "Invalid values"

    if count <= 0:
        return

    ninja = turtle.Turtle()
    ninja.forward(10 * count)
    ninja.left(5 * count)

    for _ in range(4):
        ninja.forward(size)
        ninja.left(90)

    draw_square(size - 5, count - 1)


if __name__ == "__main__":
    draw_square(100, 10)
    turtle.Screen().exitonclick()
