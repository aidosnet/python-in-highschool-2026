from timeit import timeit
from sys import setrecursionlimit

__author__ = "maurizio.boscaini@marconiverona.edu.it"


if __name__ == "__main__":
    number = 20
    setrecursionlimit(number ** 2)
    
    modules = ("factorial_iterative", "factorial_recursive", "factorial_memoized")

    for module_name in modules:
        elapsed_time = timeit(f"import {module_name}; {module_name}.factorial({number})")
        print(f"{elapsed_time} sec.\t{module_name.replace('_', ' ')}")
