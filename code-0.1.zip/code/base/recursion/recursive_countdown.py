__author__ = "maurizio.boscaini@marconiverona.edu.it"


def countdown(number):
    """Print a recursive countdown from number to 1."""
    if number > 0:
        print(number)
        countdown(number - 1)


if __name__ == "__main__":
    countdown(1000)
