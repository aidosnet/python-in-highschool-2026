"""Animate a walking dog sprite with keyboard controls using py5."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

from pathlib import Path

import py5


WINDOW_WIDTH = 960
WINDOW_HEIGHT = 600
FRAME_COUNT = 10
FRAME_RATE = 25
MOVE_STEP = 10
GROUND_Y = 356
JUMP_SPEED = -18
GRAVITY = 1.2

ASSET_DIR = Path(__file__).with_name("dog-walk")

background_image = None
dog_images = []
frame_index = 0
dog_x = 430
dog_y = GROUND_Y
y_speed = 0
is_jumping = False


def settings():
    py5.size(WINDOW_WIDTH, WINDOW_HEIGHT)


def setup():
    global background_image

    background_image = py5.load_image(str(ASSET_DIR / "background.gif"))
    background_image.resize(py5.width, py5.height)

    for frame_number in range(1, FRAME_COUNT + 1):
        filename = ASSET_DIR / f"Walk{frame_number:02}.gif"
        dog_images.append(py5.load_image(str(filename)))

    py5.frame_rate(FRAME_RATE)


def draw():
    global frame_index, dog_y, y_speed, is_jumping

    py5.background(background_image)
    py5.image(dog_images[frame_index], dog_x, dog_y)

    frame_index = (frame_index + 1) % FRAME_COUNT

    if is_jumping:
        dog_y += y_speed
        y_speed += GRAVITY

        if dog_y >= GROUND_Y:
            dog_y = GROUND_Y
            y_speed = 0
            is_jumping = False


def key_pressed():
    global dog_x, y_speed, is_jumping

    if py5.key_code == py5.LEFT:
        dog_x -= MOVE_STEP
    elif py5.key_code == py5.RIGHT:
        dog_x += MOVE_STEP
    elif py5.key == " " and not is_jumping:
        y_speed = JUMP_SPEED
        is_jumping = True

    dog_x = py5.constrain(dog_x, 0, py5.width - dog_images[0].width)


py5.run_sketch()
