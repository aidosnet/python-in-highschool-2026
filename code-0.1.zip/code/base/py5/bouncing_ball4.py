__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "3.0 2024-02-01"

import time
from py5 import *
import py5


extent = 100
speed_x = 12
speed_y = 3
x, y = 0, 0
x_min, x_max = 0, 0
y_min, y_max = 0, 0


def settings():
    """Initialize the drawing window."""
    size(800, 450)


def setup():
    """Init function is executed one time when the program starts."""
    global x, y, x_min, x_max, y_min, y_max
    fill(255, 0, 0)

    x = py5.width / 2
    y = py5.height / 2

    x_max = py5.width - extent / 2
    x_min = extent / 2

    y_max = py5.height - extent / 2
    y_min = extent / 2

    background(255)
    # py5.delay(1000) # Available in Processing, but not in py5.
    time.sleep(1)


def draw():
    """Executed repeatedly."""
    global x, y, speed_x, speed_y
    
    background(255)
    circle(x, y, extent)  # x, y, side
    x += speed_x
    y += speed_y

    # x = min(x, py5.width - extent / 2)
    # x = max(x, extent / 2)

    if x > x_max or x < x_min:
        speed_x = -speed_x

    if y > y_max or y < y_min:
        speed_y = -speed_y


run_sketch()  # Run the py5 sketch
