"""
Piastrella (tile) il display con una riga di squares colorati casualmente.

"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "1.0 2024-02-02"

import py5


def settings():
    """Initialize the drawing window."""
    py5.size(800, 450)


def setup():
    """Init function is executed one time when the program starts."""
    py5.background(255)
    draw_square_row(side=50)


def draw():
    """Executed repeatedly."""


def draw_square_row(side):
    """Piastrella il canvas con una griglia di squares colorati di lato side."""
    y = 0
    py5.stroke(255)  # Imposta a bianco il colore del bordo
    py5.stroke_weight(1)

    while y < py5.height:  # Ciclo per le righe
        x = 0

        while x < py5.width:
            r = py5.random(256)
            g = py5.random(256)
            b = py5.random(256)
            py5.fill(r, g, b)
            print(str(x) +" "+ str(y))
            py5.square(x, y, side)
            x += side

        y += side

py5.run_sketch()
