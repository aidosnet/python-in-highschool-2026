__author__ = "maurizio.boscaini@marconiverona.edu.it"

import py5

basename = "data/DragonFlybyLex/DragonFlybyLex"
num_shapes = 4
images = []
index = 0

def settings():
    """Initialize the window."""
    py5.size(800, 450)

def setup():
    """Load the animation GIF images."""
    for i in range(1, num_shapes + 1):
        # filename = basename + str(i) + ".gif"
        filename = f"{basename}{i}.gif" # data/DragonFlybyLex/DragonFlybyLex1.gif,...
        image = py5.load_image(filename)
        images.append(image)
        
    py5.frame_rate(30)

def draw():
    """Simulate flight by alternating the selected frames."""
    global index
    
    py5.background(255)
    x = (py5.width - images[index].width) // 2
    y = (py5.height - images[index].height) // 2
    py5.image(images[index], x, y)
    
    # Method 1
    index = (index + 1) % num_shapes

    # Method 2
    # index = index + 1
    # if index > 3:
    #     index = 0

py5.run_sketch()
