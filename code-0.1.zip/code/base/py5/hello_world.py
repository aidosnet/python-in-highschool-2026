"""
Display a greeting in the console and in the graphics window.

"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "1.0 2021-01-20"

import py5

def settings():
    """Initialize the drawing window."""
    print("Hello, World!")
    py5.size(800, 450)

def setup():
    """Init function is executed one time when the program starts."""
    py5.background(255)
    # py5.frame_rate(1)

def draw():
    py5.background(255)
    py5.text_size(50)
    py5.fill(0, 10)
    py5.text("Hello, World!", 0, 100)

py5.run_sketch()  # Run the py5 sketch

