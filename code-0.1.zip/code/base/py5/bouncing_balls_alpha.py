__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "6.0 2026-02-06"

import time
from py5 import *
import py5

N_BALLS = 100

balls = []

def settings():
    """Initialize the drawing window."""
    size(800, 450)

def setup():
    """Init function is executed one time when the program starts."""
    init()
    background(255)
    # delay(1000) # Available in Processing, but not in py5.
    time.sleep(1)

def init():
    """Createte the list of circle coordinates."""
    global x_min, x_max, y_min, y_max

    for _ in range(N_BALLS):
        speed_x = random(2, 10)
        speed_y = random(2, 10)
        extent = random(10, 40)
        alpha = random(0, 220)

        x = random(extent / 2, py5.width - extent / 2)
        y = random(extent / 2, py5.height - extent / 2)

        x_min = extent / 2
        x_max = py5.width - extent / 2

        y_min = extent / 2
        y_max = py5.height - extent / 2

        balls.append((x, y, speed_x, speed_y, extent, x_min, x_max, y_min, y_max, alpha))

def draw():
    """Executed repeatedly."""
    global balls
    
    background(255)
    
    for i in range(N_BALLS):
        x, y, speed_x, speed_y, extent, x_min, x_max, y_min, y_max, alpha = balls[i]

        fill(255, 0, 0, alpha)
        circle(x, y, extent)  # x, y, side
        x += speed_x
        y += speed_y

        if x > x_max or x < x_min:
            speed_x = -speed_x

        if y > y_max or y < y_min:
            speed_y = -speed_y

        balls[i] = x, y, speed_x, speed_y, extent, x_min, x_max, y_min, y_max, alpha

run_sketch()  # Run the py5 sketch
