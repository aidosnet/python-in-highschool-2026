__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "1.0 2021-01-20"

from py5 import *
import py5

x = 0
y = 0
extent = 100

def settings():
    """Initialize the drawing window."""
    size(800, 450)


def setup():
    """Init function is executed one time when the program starts."""
    global x, y
    fill(255, 0, 0)
    x = py5.width / 2
    y = py5.height / 2


def draw():
    """Executed repeatedly."""
    background(255)
    circle(x, y, extent)  # x, y, side


run_sketch()  # Run the py5 sketch
