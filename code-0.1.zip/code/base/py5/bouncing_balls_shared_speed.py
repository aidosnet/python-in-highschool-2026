__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "5.0 2024-02-01"

import time
from py5 import *
import py5

N_BALLS = 10

extent = 100
speed_x = 12
speed_y = 3
coords = []
x_min, x_max = 0, 0
y_min, y_max = 0, 0


def settings():
    """Initialize the drawing window."""
    size(800, 450)


def setup():
    """Init function is executed one time when the program starts."""
    global coords, x_min, x_max, y_min, y_max
    fill(255, 0, 0)

    init()

    x_max = py5.width - extent / 2
    x_min = extent / 2

    y_max = py5.height - extent / 2
    y_min = extent / 2

    background(255)
    # py5.delay(1000) # Available in Processing, but not in py5.
    time.sleep(1)

def init():
    """Createte the list of circle coordinates."""
    for _ in range(N_BALLS):
        x = py5.random(extent / 2, py5.width - extent / 2)
        y = py5.random(extent / 2, py5.height - extent / 2)
        coords.append([x, y])

def draw():
    """Executed repeatedly."""
    global coords, speed_x, speed_y
    
    background(255)
    
    for i in range(N_BALLS):
        circle(coords[i][0], coords[i][1], extent)  # x, y, side
        coords[i][0] += speed_x
        coords[i][1] += speed_y
        x, y = coords[i][0], coords[i][1]

        if x > x_max or x < x_min:
            speed_x = -speed_x

        if y > y_max or y < y_min:
            speed_y = -speed_y

run_sketch()  # Run the py5 sketch
