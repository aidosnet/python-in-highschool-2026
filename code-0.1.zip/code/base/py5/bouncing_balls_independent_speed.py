__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "5.0 2024-02-01"

import time
from py5 import *
import py5

N_BALLS = 30

extent = 40
balls = []
x_min, x_max = 0, 0
y_min, y_max = 0, 0

def settings():
    """Initialize the drawing window."""
    size(800, 450)

def setup():
    """Init function is executed one time when the program starts."""
    init()
    fill(255, 0, 0)
    background(255)
    # delay(1000) # Available in Processing, but not in py5.
    time.sleep(1)

def init():
    """Createte the list of circle coordinates."""
    global x_min, x_max, y_min, y_max
    x_max = py5.width - extent / 2
    x_min = extent / 2

    y_max = py5.height - extent / 2
    y_min = extent / 2

    for _ in range(N_BALLS):
        x = random(extent / 2, py5.width - extent / 2)
        y = random(extent / 2, py5.height - extent / 2)
        speed_x = random(2, 10)
        speed_y = random(2, 10)
        balls.append((x, y, speed_x, speed_y))

def draw():
    """Executed repeatedly."""
    global balls
    
    background(255)
    
    for i in range(N_BALLS):
        x, y, speed_x, speed_y = balls[i]

        circle(x, y, extent)  # x, y, side
        x += speed_x
        y += speed_y

        if x > x_max or x < x_min:
            speed_x = -speed_x

        if y > y_max or y < y_min:
            speed_y = -speed_y

        balls[i] = x, y, speed_x, speed_y

run_sketch()  # Run the py5 sketch
