__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "1.0 2021-01-20"

import time
from py5 import *
import py5

x, y = 0, 0
extent = 100
speed_x = 5
x_min, x_max = 0, 0

def settings():
    """Initialize the drawing window."""
    size(800, 450)

def setup():
    """Init function is executed one time when the program starts."""
    global x, y, x_min, x_max
    fill(255, 0, 0)

    x = py5.width / 2
    y = py5.height / 2

    x_max = py5.width - extent / 2
    x_min = extent / 2

    # py5.delay(1000)  # Available in Processing, but not in py5.
    time.sleep(1)
    frame_rate(30)

def draw():
    """Executed repeatedly."""
    print(get_frame_rate())
    global x, y, speed_x
    background(255)
    circle(x, y, extent)  # x, y, side
    x += speed_x
    # y += speed_y

    # Method 1
    # x = min(x, max_x)
    # x = max(x, min_x)

    # Method 2
    if x > x_max or x < x_min:
        speed_x = -speed_x

    # Method 3
    # if x > x_max:
    #     speed_x = -speed_x
    # elif x < x_min:
    #     speed_x = -speed_x


run_sketch()  # Run the py5 sketch
