__author__ = "maurizio.boscaini@marconiverona.edu.it"

import py5
from random import randint, choice

colors = "yellow", "pink", "blue"
path = "data/flying_birds"
bg_image = None
images = {}
num_shapes = 2
x, y = 0, 0
x_speed = 0
index = 0
current_color = None

def settings():
    py5.size(800, 450)

def setup():
    global bg_image, images, x, y, x_speed, current_color
    
    bg_image = py5.load_image(f"{path}/bg.gif")  # Load a background image
    bg_image.resize(py5.width, py5.height)

    for color in colors: # Load the frames for each color into the images dictionary
        images[color] = []
        
        for i in range(1, num_shapes + 1):
            image = py5.load_image(f"{path}/{color}{i}.gif")
            images[color].append(image)

    x = 0
    y = randint(0, py5.height - image.height)
    current_color = choice(colors)
    index = 0
    x_speed = randint(5, 40)
    py5.frame_rate(30)

def draw():
    global x, y, index, current_color
    
    py5.background(bg_image)
    py5.image(images[current_color][index], x, y)    
    x += x_speed
    
    if x > py5.width:
        x = 0
        y = randint(0, py5.height - images[current_color][0].height)
        current_color = choice(colors)
        index = 0
    else:
        index = (index + 1) % num_shapes

py5.run_sketch()
