"""
Visualizza un quadrato giallo.

"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "1.0 2021-01-20"

from py5 import *


def settings():
    """Initialize the drawing window."""
    size(800, 450)


def setup():
    """Init function is executed one time when the program starts."""
    background(255)
    fill(255, 255, 0)  # Imposta il colore giallo come colore di riempimento
    square(100, 200, 50)  # x, y, side


run_sketch()  # Run the py5 sketch
