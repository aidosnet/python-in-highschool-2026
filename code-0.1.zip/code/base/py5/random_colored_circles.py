"""
Draw randomly colored circles at random positions. Each call to draw() creates a new circle. Circles on the left half are red, and circles on the right half are blue.

"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "1.0 2021-01-20"

import py5


def settings():
    """Initialize the drawing window."""
    py5.size(800, 450)


def setup():
    """Init function is executed one time when the program starts."""


def draw():
    """Executed repeatedly."""
    x = py5.random(py5.width)
    y = py5.random(py5.height)
    min_channel = 50
    r, g, b = min_channel, min_channel, min_channel

    if x > py5.width / 2:
        b = py5.random(min_channel, 256)
    else:
        r = py5.random(min_channel, 256)

    a = py5.random(0, 256)

    py5.fill(r, g, b, a)
    py5.no_stroke()
    # py5.square(x, y, 40)  # x, y, side
    radius = py5.random(5, 100)
    py5.circle(x, y, radius)


py5.run_sketch()
