__author__ = "maurizio.boscaini@marconiverona.edu.it"

def insertion_sort(items: list[int]) -> None:
    """Sort a list of integers in place using the insertion sort algorithm.

    The algorithm takes each value from the unsorted part and inserts it
    into the correct position in the already sorted part.

    >>> values = [64, 25, 98, 90, 62, 11, 87, 34]
    >>> insertion_sort(values)
    >>> values
    [11, 25, 34, 62, 64, 87, 90, 98]
    """
    for i in range(1, len(items)):
        key = items[i]
        j = i - 1

        # Shift the larger values one position to the right.
        while j >= 0 and key < items[j]:
            items[j + 1] = items[j]
            j -= 1

        items[j + 1] = key


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=False)
