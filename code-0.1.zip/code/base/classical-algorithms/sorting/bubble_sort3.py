__author__ = "maurizio.boscaini@marconiverona.edu.it"

def bubble_sort(items: list[int]) -> None:
    """Sort a list of integers in place using the bubble sort algorithm.

    The algorithm repeatedly compares neighboring values and swaps them
    when they are in the wrong order.

    This version does not check the already sorted tail and stops early if
    no values were swapped during a pass.

    >>> values = [64, 25, 98, 90, 62, 11, 87, 34]
    >>> bubble_sort(values)
    >>> values
    [11, 25, 34, 62, 64, 87, 90, 98]
    """
    for i in range(len(items) - 1):  # Make one pass for each position except the last.
        swapped = False

        for j in range(len(items) - 1 - i):  # Stop before the already sorted tail.
            if items[j] > items[j + 1]:
                items[j], items[j + 1] = items[j + 1], items[j]
                swapped = True

        # If no values were swapped, the list is already sorted.
        if not swapped:
            break


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=False)
