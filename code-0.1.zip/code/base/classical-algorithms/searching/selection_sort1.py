__author__ = "maurizio.boscaini@marconiverona.edu.it"

def selection_sort(items: list[int]) -> None:
    """Sort a list of integers in place using the selection sort algorithm.

    The algorithm repeatedly looks for the smallest value in the unsorted
    part of the list and swaps it into the next sorted position.

    >>> values = [64, 25, 98, 90, 62, 11, 87, 34]
    >>> selection_sort(values)
    >>> values
    [11, 25, 34, 62, 64, 87, 90, 98]
    """
    for i in range(len(items) - 1):
        min_index = i

        # Find the smallest value in the unsorted tail.
        for j in range(i + 1, len(items)):
            if items[j] < items[min_index]:
                min_index = j

        items[i], items[min_index] = items[min_index], items[i]


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=False)
