__author__ = "maurizio.boscaini@marconiverona.edu.it"

def binary_search(items: list[int], target_item: int) -> int:
    """Return the index of target_item in items, or -1 if it is not present.

    The algorithm repeatedly checks the middle of the current search interval
    and keeps only the half where the target value can still be.

    >>> binary_search([11, 25, 34, 62, 64, 87, 90, 98], 63)
    -1
    >>> binary_search([11, 25, 34, 62, 64, 87, 90, 98], 64)
    4
    """
    start = 0
    end = len(items) - 1

    while start <= end:
        # print(items[start], items[end], start, end)
        index = (end + start) // 2  # Start from the middle.

        if items[index] == target_item:
            return index
        elif items[index] > target_item:
            end = index - 1
        else:
            start = index + 1

    return -1


if __name__ == "__main__":
    items = [11, 25, 34, 62, 64, 87, 90, 98]
    print(binary_search(items, 63))
    import doctest

    doctest.testmod(verbose=True)
