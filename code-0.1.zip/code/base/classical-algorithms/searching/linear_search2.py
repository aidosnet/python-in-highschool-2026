"""Program that implements linear search."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

def linear_search(items: list[int], target_item: int) -> int:
    """Return the index of target_item in items, or -1 if it is not present.

    The algorithm checks the values one by one from the beginning of the list
    until it finds the target value or reaches the end.

    >>> linear_search([11, 25, 34, 62, 64, 87, 90, 98], 63)
    -1
    >>> linear_search([11, 25, 34, 62, 64, 87, 90, 98], 64)
    4
    """
    for i, item in enumerate(items):
        if item == target_item:
            return i

    return -1


if __name__ == "__main__":
    # items = [11, 25, 34, 62, 64, 87, 90, 98]
    # print(linear_search(items, 63))
    import doctest

    doctest.testmod(verbose=True)
