__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "1.0 2021-01-25"

def encodeRLE(s):
    """Return a string compressed with RLE (Run-Length Encoding),
    ipotizzando sequenze di simboli con lunghezza <= 9.
    >>> encodeRLE("00000111101")
    '05140111'
    >>> encodeRLE("AAAACCAAATTTTTT")
    'A4C2A3T6'
    >>> encodeRLE("")
    ''
    >>> encodeRLE("010101")
    '011101110111'
    """
    result = ""
    prev_char = None
    
    for char in s:
        if char != prev_char:
            if prev_char:  # Se prevChar != None
                result += prev_char + str(count)
            
            count = 1  # Parto da 1
            prev_char = char
        else:
            count += 1  # Incremento di 1

    if prev_char:  # Se prevChar != None
        result += prev_char + str(count)
    
    return result

def encodeRLE2(s):
    """Return a string compressed with RLE (Run-Length Encoding),
    ipotizzando sequenze di simboli con lunghezza <= 9.
    >>> encodeRLE2("00000111101")
    '05140111'
    >>> encodeRLE2("AAAACCAAATTTTTT")
    'A4C2A3T6'
    >>> encodeRLE2("")
    ''
    >>> encodeRLE2("010101")
    '011101110111'
    """
    result = ""
    i = 0
    prev_char = None
    
    while i < len(s):
        if s[i] == prev_char:
            count += 1
        else:
            if prev_char:  # Se prevChar != None
                result += prev_char + str(count)
            
            count = 1
            prev_char = s[i]
        
        i += 1

    if prev_char:  # Se prevChar != None
        result += prev_char + str(count)
    
    return result
    
def decodeRLE(s):
    """Return the string corresponding to the RLE-decompressed input string,
    ipotizzando sequenze di simboli con lunghezza <= 9.
    >>> decodeRLE("05140111")
    '00000111101'
    >>> decodeRLE("A4C2A3T6")
    'AAAACCAAATTTTTT'
    """
    assert len(s) % 2 == 0, "Stringa da decoficare non riconosciuta"
    
    result = ""
    
    try:
        for i in range(0, len(s), 2):
            char = s[i]
            n = int(s[i + 1])
            result += char * n
    except ValueError:
        print("Stringa da decoficare non riconosciuta")
        return
        # Sarebbe più corretto lanciare un eccezione
        raise ValueError("Stringa da decoficare non riconosciuta")
    
    return result

if __name__ == "__main__":
    encodeRLE("AAAAABCC")
    encodeRLE("00000111101")
    import doctest
    doctest.testmod(verbose=True)
    # Se la lunghezza della sequenza di simboli uguali è > 9
    # posso spezzare la sequenza in blocchi di al massimo 9 simboli:
    # per es. "aaaaaaaaaaaaaaa" -> "a9a6"

