__author__ = "maurizio.boscaini@marconiverona.edu.it"



def factorial(number):
    """Return the factorial of a number.

    >>> factorial(5)
    120
    >>> factorial(6)
    720
    """
    result = 1

    for factor in range(1, number + 1):
        result *= factor

    return result


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)
