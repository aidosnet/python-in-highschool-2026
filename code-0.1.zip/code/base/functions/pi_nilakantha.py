__author__ = "maurizio.boscaini@marconiverona.edu.it"


def pi_nilakantha(n):
    """Calculate an approximation of pi up to the nth term of the series.
    della formula di Nilakantha.

    """
    tot = 0
    
    for i in range(1, n + 1):
        tot += (-1)**(i - 1) / (i * (i + 1) * (i + i + 1))
    
    return tot + 3
    
if __name__ == "__main__":
    for i in range(1, 47):
        print(pi_nilakantha(i))
