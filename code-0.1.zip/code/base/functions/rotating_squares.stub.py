__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "0.1 2020-12-21"

def rotating_squares(size, angle):
    """Draw continuously rotating squares of a given size, rotating of angle degree
    between two consecutive squares"""

if __name__ == "__main__":    
    rotating_squares(100)
