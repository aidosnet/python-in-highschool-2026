__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "1.0 2022-12-16"

from turtle import Screen, Turtle, setworldcoordinates, colormode
from random import randint, seed

def init(w, h):
    """Initialize the drawing environment with a w x h canvas and the origin in the upper-left corner."""
    
def draw_points(n, w, h):
    """Draw n random points on the canvas."""

w, h = 800, 450
init(w, h)
draw_points(20, w, h)
