__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "0.1 2020-12-21"

import turtle
from random import randint

def draw_random_confetti(w, h):
    """Draw continuously colored circles, using the turtle dot() method
    in a window w x h.
    """
    turtle.setup(w, h)
    turtle.colormode(255)
    ninja = turtle.Turtle()
    ninja.hideturtle()
    ninja.speed(0)
    ninja.up()
    
    while True:
        x = randint(-w // 2, w // 2)
        y = randint(-h // 2, h // 2)
        
        if x < 0:
            size = randint(10, 20)
            r = randint(100, 255)
            g = 0
            b = 0
        else:
            size = randint(20, 50)
            r = 0
            g = 0
            b = randint(100, 255)
        ninja.goto(x, y)
        ninja.color(r, g, b)
        ninja.dot(size)

if __name__ == "__main__":    
    draw_random_confetti(800, 400)
