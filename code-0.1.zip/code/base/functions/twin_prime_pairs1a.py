"""
Write a TDD program that prints all twin prime pairs where the first number in the pair is less than n.
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2025-01-15"

def is_prime(n):
    """Check whether a number is prime.

    >>> is_prime(2)
    True
    >>> is_prime(15)
    False
    >>> is_prime(19)
    True
    """
    return True

def twin_prime_pair(n1, n2):
    """Controla se n1 e n2 sono una coppia di numeri primi gemelli.

    >>> twin_prime_pair(7, 9)
    False
    >>> twin_prime_pair(17, 19)
    True
    >>> twin_prime_pair(19, 17)
    True
    >>> twin_prime_pair(19, 17)
    True
    """
    return True

def print_twin_prime_pair(n):
    """Print the twin prime pairs where the smaller value is between 2 and n.
    """
    print(5, 7)

if __name__ == '__main__':
    print_twin_prime_pair(10)
