__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "0.1 2020-12-21"

def draw_random_confetti(w, h):
    """Draw continuously colored circles, using the turtle dot() method
    in a window w x h.
    """

if __name__ == "__main__":    
    draw_random_confetti(800, 600)
