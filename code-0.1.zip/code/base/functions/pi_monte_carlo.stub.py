__author__ = "maurizio.boscaini@marconiverona.edu.it"

def pi_greco(n):
    """Calculate an approximation of pi.
    utilizzando il metodo Monte Carlo, utilizzando n gocce elettroniche"""

if __name__ == "__main__":
    print(pi_greco(100))


