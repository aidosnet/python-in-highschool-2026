__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "0.1 2020-12-11"


def print_number_triangle(row_count):
    """Print a number triangle with the given number of rows.
    
    >>> print_number_triangle(5)
    1
    12
    123
    1234
    12345
    """
    for row in range(1, row_count + 1):
        for number in range(1, row + 1):
            print(number, end="")
        
        print()

if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)
