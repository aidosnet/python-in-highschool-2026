__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "0.1 2020-12-21"

from turtle import Turtle, Screen
from random import randint, choice

def policoriandoli2(w, h, colors):
    """Draw continuously colored connected circle, using the turtle dot() method
    in a window w x h.
    The color is chosen from the list of given colors.
    """

if __name__ == "__main__":
    colors = ("red", "green", "blue", "orange", "purple")
    policoriandoli2(800, 450, colors)
