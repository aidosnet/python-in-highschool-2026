"""
Draw random colored lines with random sizes.
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "0.1 2019-01-11"

import turtle
from random import randint

def draw_random_points(ninja, dim=1):
    """Draw a random point with a random position, RGB color, and diameter.
    """
    turtle.colormode(255) # Set color values from 0 to 255
    ninja.pensize(dim)  # Set the pen size
    ninja.penup()
    r, g, b = randint(0, 255), randint(0, 255), randint(0, 255)
    ninja.pencolor((r, g, b)) # Random RGB color
    
    # Move the turtle
    x = randint(-200 ,200)
    y = randint(-200 ,200)
    ninja.goto(x, y)
    
    # Draw at the point
    ninja.pendown()
    ninja.goto(x, y)

if __name__ == "__main__":
    ninja = turtle.Turtle()     # Createte a turtle
    
    for _ in range(100):
        dim = randint(1, 40)
        draw_random_points(ninja, dim=dim)
