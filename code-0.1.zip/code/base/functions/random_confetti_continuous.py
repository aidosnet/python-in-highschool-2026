__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "0.1 2020-12-21"

import turtle
from random import randint

def draw_random_confetti(w, h):
    """Draw continuously colored circles, using the turtle dot() method
    in a window w x h.
    """
    turtle.setup(w, h)
    turtle.colormode(255)
    ninja = turtle.Turtle()
    ninja.hideturtle()
    ninja.speed(0)
    ninja.up()
    
    while True:
        r = randint(0, 255)
        g = randint(0, 255)
        b = randint(0, 255)
        size = randint(5, 50)
        x = randint(-w // 2, w // 2)
        y = randint(-h // 2, h // 2)
        ninja.goto(x, y)
        # ninja.color(r, g, b)
        ninja.dot(size, (r, g, b))

if __name__ == "__main__":    
    draw_random_confetti(800, 400)
