__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "0.1 2022-01-14"

def is_perfect(n):
    """Return True if n is perfect, False otherwise.
    If n is an integer <= 0 or n is not an integer, raise an exception.

    >>> is_perfect(10)
    False
    >>> is_perfect(6)
    True
    >>> is_perfect(28)
    True
    """

def print_perfect_numbers(n):
    """Print all perfect numbers below or equal to n
    
    >>> print_perfect_numbers(100)
    6
    28
    """

if __name__ == "__main__":
    import doctest
    doctest.testmod()
