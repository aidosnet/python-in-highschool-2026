__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "0.1 2020-12-21"

from turtle import Turtle, Screen
from random import randint, choice

def draw_connected_confetti(w, h, colors):
    """Draw continuously colored connected circle, using the turtle dot() method
    in a window w x h.
    The color is chosen from the list of given colors.
    """
    screen = Screen()
    screen.setup(w, h)
    ninja = Turtle()
    ninja.ht()  # ht == hideturtle
    print(ninja.color())
    while True:
        x = randint(-w // 2, w // 2)
        y = randint(-h // 2, h // 2)
        color = choice(colors)
        ninja.color(color)
        ninja.goto(x, y)
        ninja.dot(20)
        

if __name__ == "__main__":
    colors = ("red", "green", "blue", "orange", "purple")
    draw_connected_confetti(800, 450, colors)
