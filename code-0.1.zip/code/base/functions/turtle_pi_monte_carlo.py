"""
Metodo monte carlo
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "0.1 2019-02-01"

import random
import math
import turtle

def random_punti(n, scala=200):
    """Genera per n volte due numeri casuali x e y compresi tra [0 e 1)
    e ritorna quante coppie (x, y) distano meno di 1 dall'origine
    and draw the corresponding points on the canvas.
    """
    ninja = turtle.Turtle()
    ninja.hideturtle()
    ninja.penup()
    ninja.speed(0)
    turtle.tracer(0)
    cont = 0
    
    for _ in range(step_count):
        x = random.random()
        y = random.random()
        
        ninja.goto(x * scala, y * scala)
        
        if x*x + y*y < 1:  # math.sqrt(x*x + y*y) < 1
            cont += 1
            ninja.pencolor("green")
        else:
            ninja.pencolor("red")
            
        ninja.dot()

    turtle.update()
    return cont

if __name__ == "__main__":
    n_gocce_totali = 10000
    n_gocce_interne = random_punti(n_gocce_totali)
    print("Number of points with sqrt(x*x + y*y) < 1:", n_gocce_interne)
    pi = 4 * n_gocce_interne / n_gocce_totali
    print("Pi greco:", pi)

