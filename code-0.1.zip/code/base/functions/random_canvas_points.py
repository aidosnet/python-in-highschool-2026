__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "1.0 2022-12-16"

from turtle import Screen, Turtle, setworldcoordinates, colormode
from random import randint, seed

def init(w, h):
    """Initialize the drawing environment with a w x h canvas and the origin in the upper-left corner."""
    screen = Screen()
    screen.setup(w, h)
    setworldcoordinates(0, h, w, 0) # Sistema di riferimento della computer grafica (0, 0) in alto a turn_left
    
def draw_points(n, w, h):
    """Draw n random points on the canvas."""
    colormode(255)
    ninja = Turtle()
    ninja.hideturtle()
    ninja.speed(0)
    ninja.up()
    seed(0)
    
    for i in range(step_count):
        r, g, b = randint(0, 255), randint(0, 255), randint(0, 255)
        x = randint(0, w)
        y = randint(0, h)
        ninja.goto(x, y)
        ninja.color(r, g, b)
        ninja.dot(20)

w, h = 800, 450
init(w, h)
draw_points(20, w, h)
