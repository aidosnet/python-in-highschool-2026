__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "0.1 2021-12-23"

import turtle
from random import randint

def draw_square(size):
    """Draw a square of a given size"""
    for i in range(4):
        turtle.forward(size)
        turtle.left(90)

def draw_squares(n):
    """Draw n squares of random size
    distributed randomly in the canvas."""
    screen = turtle.Screen()
    screen.tracer(0)

    for i in range(100):
        turtle.up()
        x, y = randint(-200, 200), randint(-200, 200)
        turtle.goto(x, y)
        turtle.down()
        size = randint(5, 20)
        draw_square(size)

    screen.update()
    
draw_squares(100)    
    
    
