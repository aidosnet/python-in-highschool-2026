__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "0.1 2022-01-14"

def is_perfect(n):
    """Return True if n is perfect, False otherwise.
    If n is an integer <= 0 or n is not an integer, raise an exception.

    >>> is_perfect(10)
    False
    >>> is_perfect(6)
    True
    >>> is_perfect(28)
    True
    """
    assert n > 0, "I numeri perfetti devono essere interi positivi"
    assert type(n) == type(1), "The passed value is not an integer"
    
    _sum = 0
    
    for i in range(1, n):
        if n % i == 0:
            _sum += i

    return _sum == n

def print_perfect_numbers(n):
    """Print all perfect numbers below or equal to n
    
    >>> print_perfect_numbers(100)
    6
    28
    """
    for i in range(1, n + 1):
        if is_perfect(i):
            print(i)

if __name__ == "__main__":
    import doctest
    doctest.testmod()
