__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "0.1 2021-12-23"

import turtle
from random import randint

def draw_square(size):
    """Draw a square of a given size"""

def draw_squares(n):
    """Draw n squares of random size
    distributed randomly in the canvas."""
    screen = turtle.Screen()
    screen.tracer(0)
    
    # TODO
    
    screen.update()
    
draw_squares(100)    
    
    
