__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "0.1 2020-12-11"


def is_triangle(side_a, side_b, side_c):
    """Return True if the three sides can form a triangle, False otherwise.
    
    >>> is_triangle(3, 4, 5)
    True
    >>> is_triangle(3, 4, 9)
    False
    >>> is_triangle(0, 4, 5)
    False
    >>> is_triangle(-3, -4, -5)
    False
    """

if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)
