__author__ = "maurizio.boscaini@marconiverona.edu.it"



def is_prime(number):
    """Return True if number is prime, False otherwise.

    >>> is_prime(127)
    True
    >>> is_prime(12773)
    False
    >>> is_prime(19)
    True
    >>> is_prime(1)
    False
    """
    if number < 2:
        return False

    for divisor in range(2, number):
        if number % divisor == 0:
            return False

    return True


if __name__ == "__main__":
    import doctest

    doctest.testmod()
