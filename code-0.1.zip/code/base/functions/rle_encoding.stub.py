__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "1.0 2021-01-25"

def encodeRLE(s):
    """Return a string compressed with RLE (Run-Length Encoding),
    ipotizzando sequenze di simboli con lunghezza <= 9.
    >>> encodeRLE("00000111101")
    '05140111'
    >>> encodeRLE("AAAACCAAATTTTTT")
    'A4C2A3T6'
    >>> encodeRLE("010101")
    '011101110111'
    """
    
def decodeRLE(s):
    """Return the string corresponding to the RLE-decompressed input string,
    ipotizzando sequenze di simboli con lunghezza <= 9.
    >>> decodeRLE("05140111")
    '00000111101'
    >>> decodeRLE("A4C2A3T6")
    'AAAACCAAATTTTTT'
    """


if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)


