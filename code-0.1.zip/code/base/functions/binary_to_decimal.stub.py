__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "0.1 2020-12-18"

def binary_to_decimal(binary_number):
    """Return the number with the decimal representation of a binary number
    contained in the given string binary_number, without using builtin functions,
    without using predefined functions.

    >>> binary_to_decimal('101')
    5
    >>> binary_to_decimal('1001100')
    76
    >>> binary_to_decimal('1001100') == int('1001100', 2)
    True
    """
    result = 0
    
    for char in binary_number:
        if char == "1":
            result = result*2 + 1
        else:
            result = result*2
    
    return result

if __name__ == "__main__":    
    import doctest
    doctest.testmod(verbose=True)
