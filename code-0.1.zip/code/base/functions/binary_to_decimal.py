__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "0.1 2020-12-18"

def binary_to_decimal1(binary_number):
    """Return the number with the decimal representation of a binary number
    contained in the given string binary_number, without using builtin functions,
    without using predefined functions.

    >>> binary_to_decimal1('101')
    5
    >>> binary_to_decimal1('1001100')
    76
    >>> binary_to_decimal1('1001100') == int('1001100', 2)
    True
    """
    result = 0
    weight = 1
    i = len(binary_number) - 1
    
    while i >= 0:
        bit = binary_number[i]
        bit = 1 if bit == '1' else 0
        bit = bit * weight
        result += bit
        weight *= 2
        i -= 1
    
    return result

def binary_to_decimal2(binary_number):
    """Return the number with the decimal representation of a binary number
    contained in the given string binary_number, without using builtin functions,
    without using predefined functions.

    >>> binary_to_decimal2('101')
    5
    >>> binary_to_decimal2('1001100')
    76
    >>> binary_to_decimal2('1001100') == int('1001100', 2)
    True
    """
    result = 0
    
    # Ex. '101': 1 -> 1*2 = 2 + 0 = 2 -> 2*2 + 1 = 4 + 1 = 5
    for bit in binary_number:
        # value = 1 if bit == '1' else 0
        result = result * 2 + int(bit)  # ... + value
    
    return result

def binary_to_decimal3(binary_number):
    """Return the number with the decimal representation of a binary number
    contained in the given string binary_number, without using builtin functions,
    without using predefined functions.

    >>> binary_to_decimal3('101')
    5
    >>> binary_to_decimal3('1001100')
    76
    >>> binary_to_decimal3('1001100') == int('1001100', 2)
    True
    """
    result = 0
    length = len(binary_number)
    
    for i in range(1, length + 1):
        result += int(binary_number[i - 1]) * 2**(length - i)
    
    return result

if __name__ == "__main__":
    binary_to_decimal3('101')
    import doctest
    doctest.testmod(verbose=True)
    
