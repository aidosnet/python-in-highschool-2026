"""
Programma che implementa la ricerca binaria o dicotomica o per bisezione.
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

def binary_search(items, item) -> int:
    """Restituisce l'indice di item in items,
    oppure -1 se item non è presente.
    >>> binary_search([11, 25, 34, 62, 64, 87, 90, 98], 63)
    -1
    >>> binary_search([11, 25, 34, 62, 64, 87, 90, 98], 64)
    4
    """
    start = 0
    end = len(items) - 1
    
    while start <= end:
        # print(items[start], items[end], start, end)
        index = (end + start) // 2  # Parto dalla half

        if items[index] == item:
            return index
        elif items[index] > item:
            end = index - 1
        else:
            start = index + 1
      
    return -1
    
if __name__ == "__main__":
    # items = [11, 25, 34, 62, 64, 87, 90, 98]
    # print(binary_search(items, 63))
    import doctest
    doctest.testmod(verbose=True)
