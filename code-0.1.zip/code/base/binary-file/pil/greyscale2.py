__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2020-04-30"

from PIL import Image

def grayscale(filename):
    """Given a filename, converts the contained image from colored to grayscale,
    using the method LUMA-REC.709 (non-linear) with the following coefficients for R, G, B: 0.299, 0.587 and 0.114 .
    """
    # file -> image <class Image> -> pixels <class list>
    image = Image.open(filename)
    pixels = list(image.getdata())

    for i in range(len(pixels)):
        r, g, b = pixels[i]
        average = int(0.2125 * r + 0.7154 * g + 0.0721 * b) // 3
        average = int(0.299 * r + 0.587 * g + 0.114 * b) // 3
        pixels[i] = (average, average, average)


    # pixels <class list> -> image <class Image> -> file
    image.putdata(pixels)
    return image

if __name__ == "__main__":
    image = grayscale("data/animals-with-butterflies.jpg")
    image.show() # Open the image in the default image viewer
