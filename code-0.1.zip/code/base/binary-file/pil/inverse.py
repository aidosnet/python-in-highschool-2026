__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2020-04-30"

from PIL import Image

def invert(filename):
    """Given a filename, inverts (negate) the contained image."""
    # file -> image <class Image> -> pixels <class list>
    image = Image.open(filename)
    pixels = list(image.getdata())

    for i in range(len(pixels)):
        r, g, b = pixels[i]
        r, g, b = 255 - r, 255 - g, 255 - b
        pixels[i] = (r, g, b)

    # pixels <class list> -> image <class Image> -> file
    image.putdata(pixels)
    return image

if __name__ == "__main__":
    image = invert("data/kingfisher.jpg")
    image.show() # Open the image in the default image viewer
