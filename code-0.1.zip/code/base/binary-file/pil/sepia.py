__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2020-04-30"

from PIL import Image

def sepia(filename):
    """Given a filename, converts the contained image in a sepia toning one,
    with the following coefficients for R, G, B:
    .393  .769  .189
    .349  .686  .168
    .272  .534  .131
    """
    image = Image.open(filename)
    pixels = list(image.getdata())

    for i in range(len(pixels)):
        r, g, b = pixels[i]
        r_new = min(round((.393 * r + .769 * g + .189 * b)), 255)
        g_new = min(round((.349 * r + .686 * g + .168 * b)), 255)
        b_new = min(round((.272 * r + .534 * g + .131 * b)), 255)
        pixels[i] = (r_new, g_new, b_new)

    image.putdata(pixels)
    return image

if __name__ == "__main__":
    image = sepia("data/kingfisher.jpg")
    image.show() # Open the image in the default image viewer
