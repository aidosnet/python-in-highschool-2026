__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2020-04-30"

from PIL import Image

def multicolors(filename, ncolors=10):
    """Given a filename, converts the contained image into a multicolor image.
    The original colors are subdivided into ncolors ranges, based on RGB average,
    and associated to ncolors randomly created.
    """
    from random import randint
    
    image = Image.open(filename)
    pixels = list(image.getdata())

    colors = []
    
    for i in range(ncolors):
        r = randint(0, 255)
        g = randint(0, 255)
        b = randint(0, 255)
        colors.append((r, g, b))

    subrange = 256 / ncolors

    for i in range(len(pixels)):
        r, g, b = pixels[i]
        
        average = (r + g + b) // 3
        index = int(average // subrange)
        pixels[i] = colors[index]

    image.putdata(pixels)
    return image

if __name__ == "__main__":
    image = multicolors("data/alessandro-barbero.jpg")
    image.show() # Open the image in the default image viewer
