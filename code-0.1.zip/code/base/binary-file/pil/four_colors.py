__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2020-04-30"

from PIL import Image

def four_colors(filename, colors = [(255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 0)] ):
    """Given a filename, converts the contained image into a 4 color image
    Default colors are: red, green, blue, yellow
    """
    image = Image.open(filename)
    pixels = list(image.getdata())

    for i in range(len(pixels)):
        r, g, b = pixels[i]
        
        quarter = 256 / 4
        average = (r + g + b) // 3
        
        if average < quarter * 1:
            r, g, b = colors[0]
        elif average < quarter * 2:
            r, g, b = colors[1]
        elif average < quarter * 3:
            r, g, b = colors[2]
        else:
            r, g, b = colors[3]
        
        pixels[i] = (r, g, b)

    image.putdata(pixels)
    return image

if __name__ == "__main__":
    image = four_colors("data/andy-warhol-marilyn-monroe_niagara.jpg")
    image.show() # Open the image in the default image viewer
