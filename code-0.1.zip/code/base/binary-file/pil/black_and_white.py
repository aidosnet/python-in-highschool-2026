__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2020-04-30"

from PIL import Image


def black_and_white(filename, threshold=100):
    """Given a filename, converts the contained image into black and white
    using a threshold value to choose the target color (B/W)."""
    # file -> image <class Image> -> pixels <class list>
    image = Image.open(filename)
    pixels = list(image.getdata())

    for i in range(len(pixels)):
        r, g, b = pixels[i]
        average = (r + g + b) // 3
        color = (255, 255, 255) if average > threshold else (0, 0, 0)
        pixels[i] = color

    # pixels <class list> -> image <class Image> -> file
    image.putdata(pixels)
    return image


if __name__ == "__main__":
    image = black_and_white("data/kingfisher.jpg")
    image.show()  # Open the image in the default image viewer
