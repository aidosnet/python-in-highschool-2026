__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2020-04-30"

from PIL import Image


def bichrome(filename, threshold, color1, color2):
    """Given a filename, converts the contained image into a bichrome image."""
    # file -> image <class Image> -> pixels <class list>
    image = Image.open(filename)
    pixels = list(image.getdata())

    for i in range(len(pixels)):
        r, g, b = pixels[i]
        average = (r + g + b) // 3
        color = color1 if average > threshold else color2
        pixels[i] = color

    # pixels <class list> -> image <class Image> -> file
    image.putdata(pixels)
    return image


if __name__ == "__main__":
    image = bichrome("data/kingfisher.jpg", 127, (100, 200, 50), (128, 80, 200))
    image.show()  # Open the image in the default image viewer
