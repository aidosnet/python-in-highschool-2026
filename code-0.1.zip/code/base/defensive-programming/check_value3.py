__author__ = "maurizio.boscaini@marconiverona.edu.it"

def input_int(prompt):
    """Ask the user for an integer and return it.
    Check the empty string case when the user immediately presses Enter.
    e il + e - iniziali.
    """
    value = input(prompt)
    is_int = True

    # Modo 1
    if value == "" or not value[0] in "+-0123456789":
    # Modo 2 # Non funziona per la stringa vuota
    # if not value[0] in "+-0123456789" or value == "":
        is_int = False
    else:
        for char in value[1:]:
            if not char in "0123456789":
                is_int = False

    if is_int:
        return int(value)

if __name__ == "__main__":
    value = input_int("Number? ")
    print(value)


