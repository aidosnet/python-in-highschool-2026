"""
Alla fine calcola e stampa base^exp senza utilizzare funzioni/operatori di elevamento a potenza o di radice.

"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "1.0 2025-02-13"

def input_powerof1():
    """Ask for an integer > 0 (base) and an integer >= 0 (exp),
    Se i numeri inseriti non sono corretti, continua a chiedere di reinserire entrambi.
    Alla fine ritorna i due numeri inseriti.
    """
    valid = False

    while not valid:
        try:
            base = int(input("Base (> 0)? "))
            exp = int(input("Esponente (>= 0)? "))
            valid = True
        except:
            print("\nValori inseriti non validi. Devono essere interi. Riprova.")

        if valid:
            valid = base > 0 and exp >= 0

            if not valid:
                print("\nInteri inseriti non validi. Riprova.")

    return base, exp


def input_powerof2():
    """Ask for an integer > 0 (base) and an integer >= 0 (exp),
    Se i numeri inseriti non sono corretti, continua a chiedere di reinserire entrambi.
    Alla fine ritorna i due numeri inseriti.
    """
    valid = False

    while not valid:
        try:
            base = int(input("Base (> 0)? "))
            exp = int(input("Esponente (>= 0)? "))
            valid = base > 0 and exp >= 0
        except:
            print("\nValori inseriti non validi. Devono essere interi. Riprova.")

        if not valid:
            print("\nInteri inseriti non validi. Riprova.")

    return base, exp


def input_powerof3():
    """Ask for an integer > 0 (base) and an integer >= 0 (exp),
    Se i numeri inseriti non sono corretti, continua a chiedere di reinserire entrambi.
    Alla fine ritorna i due numeri inseriti.
    """
    while True:
        try:
            base = int(input("Base (> 0)? "))
            exp = int(input("Esponente (>= 0)? "))

            if base > 0 and exp >= 0:
                return base, exp
            else:
                print("\nInteri inseriti non validi. Riprova.")
        except:
            print("\nValori inseriti non validi. Devono essere interi. Riprova.")


def input_powerof4():
    """Ask for an integer > 0 (base) and an integer >= 0 (exp),
    Se i numeri inseriti non sono corretti, continua a chiedere di reinserire entrambi.
    Alla fine ritorna i due numeri inseriti.
    """
    while True:
        try:
            base = int(input("Base (> 0)? "))
            exp = int(input("Esponente (>= 0)? "))

            assert base > 0 and exp >= 0
            return base, exp
        except:
            print("\nValori inseriti non validi. Riprova.")


def powerof1(base, exp):
    """Calculate base^exp"""
    return base**exp


def powerof2(base, exp):
    """Calculate base^exp without the ** operator and math.pow().

    >>> powerof2(2, 6)
    64
    >>> powerof2(2, 0)
    1
    >>> powerof2(9, 9)
    387420489
    """
    result = 1

    for i in range(exp):
        result *= base

    return result


if __name__ == "__main__":
    import doctest

    doctest.testmod()

    base, exp = input_powerof4()
    result = powerof2(base, exp)

    print(f"{base}^{exp} = {result}")
