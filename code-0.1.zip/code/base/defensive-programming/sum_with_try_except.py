__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "0.1 2022-02-21"

def sum_numbers(a, b):
    """Return the sum of a and b."""
    return a + b

try:
    a = int(input("a? "))
    b = int(input("b? "))
    print(f"Sum of {a} e {b} = {sum_numbers(a, b)}")
except:
    print("Error")
    import sys
    sys.exit()

print("The End")
