__author__ = "maurizio.boscaini@marconiverona.edu.it"

def input_int(prompt):
    """Ask the user for an integer and return it.
    Effettua il controllo con try-except e continua
    asking for the number until
    può essere convertito in intero.
    """
    while True:
        try:
            return int(input(prompt))
            print("Magilla")
        except:
            print("Valore non valido\n")

if __name__ == "__main__":
    value = input_int("Number? ")
    print(value)


