__author__ = "maurizio.boscaini@marconiverona.edu.it"

def input_int(prompt):
    """Ask the user for an integer and return it.
    Check whether the entered characters are digits.
    Works only with positive integers without a sign and does not work if the user immediately presses Enter.
    """
    value = input(prompt)
    is_int = True  # Flag that tells whether the input is an integer
    
    for char in value:
        if not char in "0123456789":
            is_int = False
    
    if is_int:
        return int(value)

if __name__ == "__main__":
    value = input_int("Number? ")
    print(value)


