__author__ = "maurizio.boscaini@marconiverona.edu.it"

def input_int(prompt):
    """Ask the user for an integer and return it.
    Check whether the entered characters are digits.
    Works only with positive integers without a sign and does not work if the user immediately presses Enter.
    """

if __name__ == "__main__":
    value = input_int("Number? ")
    print(value)


