__author__ = "maurizio.boscaini@marconiverona.edu.it"

def division(a: float, b: float) -> float:
    """
    """
    result = None
    
    try:
        result = a / b
        print("Divisione eseguita correttamente")
    except:
        print("Error: divisor is zero")  # Report the error to the user
        result = 0.0  # Set a default value
        import sys
        sys.exit(-1)
        
    return result
    
if __name__ == "__main__":
    a, b = 7, 0
    print(division(a, b))


