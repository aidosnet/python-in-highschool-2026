"""
Ridefiniamo l'operazione di radice quadrata
con un controllo sulla validità dell'argomento.

"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "1.0 2021-01-18"

def secure_sqrt1(n):
    """Return the square root of n if n is >= 0, otherwise print an error message. Use an if statement for validation.
    
    >>> secure_sqrt1(4)
    2.0
    >>> secure_sqrt1(0)
    0.0
    >>> secure_sqrt1(-1)
    Error: invalid value.
    """
    
def secure_sqrt2(n):
    """Return la radice quadrata di n, se n è >= 0,
    mentre visualizza un messaggio di errore se n < 0,
    utilizzando il costrutto try-except.
    
    >>> secure_sqrt2(4)
    2.0
    >>> secure_sqrt2(0)
    0.0
    >>> secure_sqrt2(-1)
    Error: invalid value.
    """

    
def secure_sqrt3(n):
    """Return the square root of n if n is >= 0, otherwise return 0.0. Use try-except.
    
    >>> secure_sqrt3(4)
    2.0
    >>> secure_sqrt3(0)
    0.0
    >>> secure_sqrt3(-1)
    0.0
    """

if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)


