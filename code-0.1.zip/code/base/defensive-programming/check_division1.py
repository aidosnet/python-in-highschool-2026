__author__ = "maurizio.boscaini@marconiverona.edu.it"

def division(a: float, b: float) -> float:
    """
    Divides two numbers and returns the result.
    Handles the division by zero exception by exiting with error code -1.

    Args:
        a (float): The dividend
        b (float): The divisor

    Returns:
        float: The result of a / b, or 0.0 if division by zero occurs

    Examples (doctests):
        >>> division(10, 2)
        Division executed successfully
        5.0

        Test with zero divisor (division by zero):
        >>> division(7, 0)  # doctest: +IGNORE_EXCEPTION_DETAIL
        Error: divisor equal to zero
        0.0
    """
    result = None

    try:
        result = a / b
        print("Division executed successfully")
    except:
        print("Error: divisor equal to zero")  # Report error to user
        result = 0.0  # Set a default value
        import sys

        sys.exit(-1)

    return result


if __name__ == "__main__":
    import doctest
    doctest.testmod()
    # a, b = 7, 0
    # print(division(a, b))
