"""
Redefine the square root operation with an argument validity check.

"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "1.0 2021-01-18"

def secure_sqrt1(n):
    """Return the square root of n if n is >= 0, otherwise print an error message. Use an if statement for validation.

    >>> secure_sqrt1(4)
    2.0
    >>> secure_sqrt1(0)
    0.0
    >>> secure_sqrt1(-1)
    Error: invalid value.
    """
    from math import sqrt

    if n >= 0:
        return sqrt(n)
    else:
        print("Error: invalid value.")


def secure_sqrt2(n):
    """Return the square root of n if n is >= 0, otherwise print an error message. Use try-except to catch any error.

    >>> secure_sqrt2(4)
    2.0
    >>> secure_sqrt2(0)
    0.0
    >>> secure_sqrt2(-1)
    Error: invalid value.
    >>> secure_sqrt2("sette")
    Error: invalid value.
    """
    from math import sqrt

    try:
        return sqrt(n)
    except:
        print("Error: invalid value.")


def secure_sqrt3(n):
    """Return the square root of n if n is >= 0, otherwise return 0.0. Use try-except.

    >>> secure_sqrt3(4)
    2.0
    >>> secure_sqrt3(0)
    0.0
    >>> secure_sqrt3(-1)
    0.0
    """
    from math import sqrt

    try:
        result = sqrt(n)
    except:
        result = 0.0

    return result


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)
