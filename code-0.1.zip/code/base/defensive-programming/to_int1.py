__author__ = "maurizio.boscaini@marconiverona.edu.it"

def to_int(n):
    """Convert n to an integer. n must already be an int or a float, otherwise an assertion is raised.
    >>> to_int(5)
    5
    >>> to_int(4.67)
    4
    >>> to_int("45")
    45
    """
    assert type(n) == type(123) or type(n) == type(123.456)
    return int(n)

if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)


