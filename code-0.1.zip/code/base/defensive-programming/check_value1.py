__author__ = "maurizio.boscaini@marconiverona.edu.it"

def input_int(prompt):
    """Ask the user for an integer and return it without validating the input.
    """
    value = int(input(prompt))
    return value

if __name__ == "__main__":
    value = input_int("Number? ")
    print(value)


