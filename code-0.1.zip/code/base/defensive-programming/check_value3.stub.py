__author__ = "maurizio.boscaini@marconiverona.edu.it"

def input_int(prompt):
    """Ask the user for an integer and return it.
    Check the empty string case when the user immediately presses Enter.
    e il + e - iniziali.
    """

if __name__ == "__main__":
    value = input_int("Number? ")
    print(value)


