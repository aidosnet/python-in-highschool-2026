__author__ = "maurizio.boscaini@marconiverona.edu.it"

from microbit import *

while True:
    if accelerometer.was_gesture("shake"):
        display.show(Image.SKULL)
        sleep(500)
    else:
        display.clear()
