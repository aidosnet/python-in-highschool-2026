__author__ = "maurizio.boscaini@marconiverona.edu.it"

from microbit import *

import random

while True:
    if button_a.is_pressed():
        result = random.choice(["Heads", "Tails"])
        display.scroll(result)
