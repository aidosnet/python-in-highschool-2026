__author__ = "maurizio.boscaini@marconiverona.edu.it"

# Add your Python code here. E.g.
from microbit import *


while True:
    sleep(1000)
    display.scroll('Hello, World!')
