__author__ = "maurizio.boscaini@marconiverona.edu.it"

from microbit import *
import time

start_time = 0
running = False

while True:
    if button_a.is_pressed() and not running:
        start_time = time.ticks_ms()
        running = True
        display.show(Image.ARROW_E)
    elif button_b.is_pressed() and running:
        elapsed_time = (time.ticks_ms() - start_time) // 1000
        display.scroll(str(elapsed_time) + "s")
        running = False
