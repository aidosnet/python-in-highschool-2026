__author__ = "maurizio.boscaini@marconiverona.edu.it"

from microbit import *

compass.calibrate()

while True:
    heading = compass.heading()
    if 345 <= heading or heading <= 15:
        display.show("N")
    else:
        display.show(Image.ARROW_N)
