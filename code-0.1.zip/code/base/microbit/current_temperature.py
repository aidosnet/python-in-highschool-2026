__author__ = "maurizio.boscaini@marconiverona.edu.it"

from microbit import *

while True:
    if button_a.is_pressed():
        current_temperature = temperature()
        display.scroll(str(current_temperature) + "C")
    if temperature() > 30:
        display.show(Image.HAPPY)
    else:
        display.clear()
