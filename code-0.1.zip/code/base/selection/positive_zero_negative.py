"""Ask for an integer and print whether it is positive, negative, or zero."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

number = int(input("Number: "))

if number > 0:
    print("Positive")
elif number < 0:
    print("Negative")
else:
    print("Zero")

if number > 0:
    print("Positive")
else:
    if number < 0:
        print("Negative")
    else:
        print("Zero")

print("Done")
