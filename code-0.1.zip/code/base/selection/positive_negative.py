"""Ask for a number and print whether it is positive or negative."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

number = float(input("Number: "))

if number >= 0:
    print("Positive")
else:
    print("Negative")
