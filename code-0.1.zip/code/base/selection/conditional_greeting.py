"""Print a greeting only if the user confirms it."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

choice = input("Print a greeting on screen (y=yes)? ")

if choice == "y":
    print("Good morning")
    print("...")

print("Done")

