"""Draw colored vertical lines using repeated instructions."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2020-11-27"

import turtle

distance = 20  # eval(input("Distance: "))
length = 100  # eval(input("Length: "))
pen_size = 5  # eval(input("Pen size: "))

ninja = turtle.Turtle()
ninja.pensize(pen_size)
ninja.shape("turtle")

ninja.pendown()
ninja.pencolor("red")
ninja.forward(length)
ninja.penup()
ninja.backward(length)
ninja.left(90)
ninja.forward(distance)
ninja.right(90)

ninja.pendown()
ninja.pencolor("green")
ninja.forward(length)
ninja.penup()
ninja.backward(length)
ninja.left(90)
ninja.forward(distance)
ninja.right(90)

ninja.pendown()
ninja.pencolor("blue")
ninja.forward(length)
ninja.penup()
ninja.backward(length)
ninja.left(90)
ninja.forward(distance)
ninja.right(90)

ninja.pencolor("black")
