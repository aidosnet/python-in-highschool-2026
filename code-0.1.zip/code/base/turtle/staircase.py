"""Draw a colored staircase
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "1.0 2022-11-22"

from turtle import *

rise = 20
tread = 30
step_count = 3

pensize(5)
color("fuchsia")

for _ in range(step_count):
    left(90)
    fd(rise)
    right(90)
    fd(tread)

color("black")
