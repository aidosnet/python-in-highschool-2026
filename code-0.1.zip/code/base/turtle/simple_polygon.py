"""Test begin, end e fillcolor()
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "1.0 2022-11-22"

from turtle import *

shape("circle")
# pencolor("brown")
pensize(4)
fillcolor("red")
begin_fill()
fd(100)
left(40)
fd(100)
left(70)
fd(100)
left(20)
end_fill()

pencolor("black")
