"""
Continuously draw rotated squares.
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "0.1 2022-11-22"

import turtle

ninja = turtle.Turtle()
print(type(ninja))
ninja.speed(0)
size = 100

# Draw continuously rotating squares of a given size
while True:  # Forever
    for i in range(4):
        ninja.fd(size)
        ninja.left(90)
        
    ninja.left(13)
