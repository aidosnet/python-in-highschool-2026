"""Draw a colored staircase
Compared with version 1.0, redefine turn and move commands, then use them in the program, for example:
turn_left = ninja.left
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "1.0 2022-11-22"

from turtle import *

rise = 20
tread = 30
step_count = 3

# Createte aliases for some commands
turn_left = left
turn_right = right
move_forward = forward

pensize(5)
color("fuchsia")

for _ in range(step_count):
    turn_left(90)
    move_forward(rise)
    turn_right(90)
    move_forward(tread)

color("black")
