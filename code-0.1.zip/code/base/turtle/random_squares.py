"""Draw random squares."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

from random import randint, uniform
from turtle import *

colormode(255)  # Set RGB channel values
speed(0)
shape("square")
resizemode("user")
penup()

for _ in range(100):
    r = randint(0, 255)
    g = randint(0, 255)
    b = randint(0, 255)
    x = randint(-400, 400)
    y = randint(-400, 400)
    radius = randint(10, 50)
    stretchfactor = uniform(1, 6)
    
    color(r, g, b)
    goto(x, y)
    shapesize(stretchfactor, stretchfactor)
    stamp()
    
exitonclick()
    
    
    
