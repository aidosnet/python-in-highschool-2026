"""
Continuously draw rotated squares.
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "0.1 2022-11-22"

import turtle

size = 100

donatello = turtle.Turtle()
michelangelo = turtle.Turtle()

donatello.speed(0)
michelangelo.speed(0)
donatello.up()
michelangelo.up()
donatello.goto(-100, 0)
michelangelo.goto(100, 0)
donatello.down()
michelangelo.down()

# Draw continuously rotating squares of a given size
while True:  # Forever
    for i in range(4):
        donatello.fd(size)
        donatello.left(90)
        michelangelo.fd(size)
        michelangelo.left(90)
        
    donatello.left(13)
    michelangelo.left(-13)
        
