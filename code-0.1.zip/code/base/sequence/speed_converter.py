"""Calculate speed in m/s and km/h."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

# Input
seconds = int(input("Seconds? "))
meters = int(input("Meters? "))

# Processing
meters_per_second = meters / seconds
kilometers = meters / 1000
kilometers_per_hour = kilometers * 3600 / seconds

# Output
print("Speed:", round(meters_per_second, 2), "m/s")
print("Speed:", round(kilometers_per_hour, 2), "km/h")
