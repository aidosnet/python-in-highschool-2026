"""Calculate compound interest."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2019-11-14"

# Input
principal = float(input("Principal? "))
years = float(input("Years? "))
rate = float(input("Rate (%)? "))

# Processing
final_capital = principal * (1 + rate / 100) ** years

# Output
print("Final capital:", final_capital)
