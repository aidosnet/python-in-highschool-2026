"""Calculate the speed of the 100 meter world record in km/h."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

__version__ = "1.0 2024-10-30"

# Input
seconds = 9.58

# Processing
seconds_per_km = (seconds * 1000) / 100
seconds_per_hour = 60 * 60
meters_per_hour = (1000 * seconds_per_hour) / seconds_per_km
kilometers_per_hour = meters_per_hour / 1000

# Output
print("km/h", kilometers_per_hour)
