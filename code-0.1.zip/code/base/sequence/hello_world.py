__author__ = "maurizio.boscaini@marconiverona.edu.it"


print("Hello, World!") 
