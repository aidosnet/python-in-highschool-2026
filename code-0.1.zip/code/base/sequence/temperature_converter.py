"""Convert a temperature from Celsius to Fahrenheit and Kelvin.

Conversion formulas:
T(°F) = T(°C) * 1,8 + 32
T(°K) = T(°C) + 273,15
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

# Input
celsius_temperature = float(input("Temperature in °C: "))

# Processing
fahrenheit_temperature = celsius_temperature * 1.8 + 32
kelvin_temperature = celsius_temperature + 273.15

# Output
print("Temperature in °F:", fahrenheit_temperature)
print("Temperature in °K:", kelvin_temperature)
