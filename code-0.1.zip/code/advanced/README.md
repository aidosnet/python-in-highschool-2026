# Advanced Python Examples

Small educational Python projects for networking, MQTT, and object-oriented
programming.

## Projects

- `socket/`: basic TCP socket examples.
- `oop/`: basic class, dataclass, and object representation examples.
- `mqtt/mqtt_temperature1/`: MQTT publisher/subscriber temperature demo.
- `mqtt/mqtt_temperature2/`: MQTT temperature demo with logging and plotting.

## Requirements

Most examples only need Python 3. The MQTT examples also need:

```bash
pip install paho-mqtt
```

The real-time plot example also needs:

```bash
pip install matplotlib
```

On Linux, the matplotlib `TkAgg` backend may require Tkinter:

```bash
sudo apt install python3-tk
```

