"""
Subscribe to an MQTT topic and plot temperature values in real time.

This script receives numeric values from the "its/temperature" topic and shows
them in a live matplotlib graph with a sliding window of recent samples.

Requirements:
    paho-mqtt
    matplotlib
    Tkinter support for the TkAgg backend

Usage:
    python mqtt_temperature_plot.py
"""

__author__ = "Mauri"
__version__ = "1.0"
__status__ = "Educational example"

import matplotlib
import matplotlib.pyplot as plt
import paho.mqtt.client as mqtt


# Configuration.
BROKER = "broker.hivemq.com"
TOPIC = "its/temperature"
MAX_POINTS = 500

matplotlib.use("TkAgg")

# Store the values shown in the graph.
data = []


def on_connect(client, userdata, flags, rc):
    """Subscribe to the temperature topic after connecting to the broker."""
    if rc == 0:
        print("Connected to broker")
        client.subscribe(TOPIC)
    else:
        print("Connection failed:", rc)


def on_message(client, userdata, msg):
    """Validate each received value and update the live plot."""
    try:
        value = float(msg.payload.decode())
    except ValueError:
        print("Invalid data received")
        return

    data.append(value)

    # Keep only the latest values for a sliding window effect.
    if len(data) > MAX_POINTS:
        data.pop(0)

    # Redraw the plot with the current data.
    plt.clf()
    plt.plot(data)
    plt.title("Temperature (real time)")
    plt.xlabel("Samples")
    plt.ylabel("Temperature (degrees Celsius)")
    plt.pause(0.01)


# Create and configure the MQTT client.
client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

client.connect(BROKER, 1883, 60)

# Enable interactive plotting before starting the MQTT loop.
plt.ion()
client.loop_forever()
