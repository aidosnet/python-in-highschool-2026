"""
Publish simulated temperature values to an MQTT topic.

Every 2 seconds, this script generates a random temperature value and publishes
it to the "its/temperature" topic. It demonstrates the publisher role in MQTT
and can be used to test subscribers, dashboards, or data processing scripts.

Requirements:
    paho-mqtt

Usage:
    python mqtt_temperature_publisher.py
"""

__author__ = "Mauri"
__version__ = "1.0"
__status__ = "Educational example"

import random
import time

import paho.mqtt.client as mqtt


# Create an MQTT client instance for connection and publishing.
client = mqtt.Client()

# Connect to the public MQTT broker on the default non-secure MQTT port.
client.connect("broker.hivemq.com", 1883)

# Continuously simulate sensor readings.
while True:
    temperature = random.randint(20, 30)

    # Publish the temperature value to all subscribers of this topic.
    client.publish("its/temperature", temperature)

    print("Sent:", temperature)

    # Control the simulated sampling rate.
    time.sleep(2)
