# MQTT Temperature 2

MQTT temperature examples with publishing, subscribing, CSV logging, and
real-time plotting.

## Files

- `mqtt_temperature_publisher.py`: publishes simulated temperature values.
- `mqtt_temperature_subscriber.py`: prints received temperature values.
- `mqtt_temperature_logger.py`: saves received values to `temperature_data.csv`.
- `mqtt_temperature_plot.py`: shows received values in a live matplotlib plot.

## Requirements

```bash
pip install paho-mqtt matplotlib
```

On Linux, the plot script may also require:

```bash
sudo apt install python3-tk
```

## Run

From the repository root, start one receiver in a terminal:

```bash
python mqtt/mqtt_temperature2/mqtt_temperature_subscriber.py
```

or:

```bash
python mqtt/mqtt_temperature2/mqtt_temperature_logger.py
```

or:

```bash
python mqtt/mqtt_temperature2/mqtt_temperature_plot.py
```

Then start the publisher in another terminal:

```bash
python mqtt/mqtt_temperature2/mqtt_temperature_publisher.py
```

All scripts use the `its/temperature` topic on `broker.hivemq.com`.

