"""
Subscribe to an MQTT topic and log temperature values to a CSV file.

Each received temperature value is saved with a Unix timestamp, topic name, and
numeric value. This script is useful for collecting MQTT sensor data for later
analysis.

Requirements:
    paho-mqtt

Usage:
    python mqtt_temperature_logger.py
"""

__author__ = "Mauri"
__version__ = "1.0"
__status__ = "Educational example"

import csv
import time

import paho.mqtt.client as mqtt


# Configuration.
BROKER = "broker.hivemq.com"
TOPIC = "its/temperature"
FILENAME = "temperature_data.csv"

# Open the CSV file in append mode.
file = open(FILENAME, "a", newline="")
writer = csv.writer(file)


def on_connect(client, userdata, flags, rc):
    """Subscribe to the temperature topic after connecting to the broker."""
    if rc == 0:
        print("Connected to broker")
        client.subscribe(TOPIC)
    else:
        print("Connection failed:", rc)


def on_message(client, userdata, msg):
    """Validate and save each received temperature message."""
    try:
        value = float(msg.payload.decode())
    except ValueError:
        print("Invalid data received")
        return

    timestamp = time.time()

    # Write the row and flush immediately so data is not lost.
    writer.writerow([timestamp, msg.topic, value])
    file.flush()

    print(f"Saved: {timestamp}, {value}")


# Create and configure the MQTT client.
client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

client.connect(BROKER, 1883, 60)
client.loop_forever()
