# MQTT Temperature 1

Basic MQTT temperature publisher/subscriber example.

The publisher generates a random temperature value every 2 seconds and sends it
to the `its/temperature` topic.

## Requirements

```bash
pip install paho-mqtt
```

## Run

From the repository root, open two terminals.

Terminal 1, start the subscriber:

```bash
python mqtt/mqtt_temperature1/mqtt_temperature_subscriber.py
```

Terminal 2, start the publisher:

```bash
python mqtt/mqtt_temperature1/mqtt_temperature_publisher.py
```

## Broker

The publisher uses the public broker `broker.hivemq.com`. The subscriber is
currently configured for a local broker at `127.0.0.1`; edit the `client.connect`
line if both scripts should use the same broker.

