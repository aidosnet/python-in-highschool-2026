"""
Subscribe to an MQTT topic and print incoming temperature values.

This script connects to an MQTT broker, subscribes to the "its/temperature"
topic, and prints every received temperature value.

Requirements:
    paho-mqtt

Usage:
    python mqtt_temperature_subscriber.py
"""

__author__ = "Mauri"
__version__ = "1.0"
__status__ = "Educational example"

import paho.mqtt.client as mqtt


def on_connect(client, userdata, flags, rc):
    """
    Subscribe to the temperature topic after a successful broker connection.

    Parameters:
        client: MQTT client instance.
        userdata: User-defined data, not used in this example.
        flags: Response flags sent by the broker.
        rc: Result code, where 0 means success.
    """
    if rc == 0:
        print("Connected successfully to broker")
        client.subscribe("its/temperature")
    else:
        print("Connection failed with code", rc)


def on_message(client, userdata, msg):
    """
    Decode and print each message received from the subscribed topic.

    Parameters:
        client: MQTT client instance.
        userdata: User-defined data, not used in this example.
        msg: Received MQTT message with topic and payload.
    """
    value = msg.payload.decode()
    print(f"Received from {msg.topic}: {value}")


# Create and configure the MQTT client.
client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

# Connect to the MQTT broker.
# client.connect("broker.hivemq.com", 1883, 60)
client.connect("127.0.0.1", 1883, 60)

# Alternative local network broker connection:
# client.connect("192.168.1.112", 1883)

# Keep listening for incoming messages.
client.loop_forever()
