"""
Define a Sensor class with a string representation.

This introductory object-oriented programming example extends the basic sensor
class with a method that returns a readable description of the object.
"""

__author__ = "Mauri"
__version__ = "1.0"
__status__ = "Educational example"


class Sensor:
    """Represent a sensor with an identifier and a type."""

    def __init__(self, identifier, sensor_type):
        """Initialize a sensor instance."""
        self.identifier = identifier
        self.sensor_type = sensor_type

    def __str__(self):
        """Return a readable description of the sensor."""
        description = ""
        description += f"id: {self.identifier}\n"
        description += f"type: {self.sensor_type}\n"
        return description
        # return f"id: {self.identifier}\ntype: {self.sensor_type}\n"


if __name__ == "__main__":
    sensor1 = Sensor("013", "temperature")
    sensor2 = Sensor("051", "temperature")
    sensor3 = Sensor("408", "humidity")

    print(sensor1)
    print(sensor1.__str__())
    # print(sensor1.identifier)
    # print(sensor1.sensor_type)
