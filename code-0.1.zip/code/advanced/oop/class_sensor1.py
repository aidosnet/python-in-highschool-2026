"""
Define a simple Sensor dataclass.

This introductory object-oriented programming example uses a dataclass to
represent a sensor with an identifier and a sensor type.
"""

__author__ = "Mauri"
__version__ = "1.0"
__status__ = "Educational example"

from dataclasses import dataclass


@dataclass
class Sensor:
    """Represent a sensor with an identifier and a type."""

    identifier: str
    sensor_type: str


if __name__ == "__main__":
    sensor1 = Sensor("013", "temperature")
    sensor2 = Sensor("051", "temperature")
    sensor3 = Sensor("408", "humidity")

    print(sensor1)
    print(sensor1.identifier)
    print(sensor1.sensor_type)
