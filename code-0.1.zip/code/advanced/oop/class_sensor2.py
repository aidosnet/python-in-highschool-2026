"""
Define a basic Sensor class.

This introductory object-oriented programming example creates a class that
represents a sensor with an identifier and a sensor type.
"""

__author__ = "Mauri"
__version__ = "1.0"
__status__ = "Educational example"


class Sensor:
    """Represent a sensor with an identifier and a type."""

    def __init__(self, identifier, sensor_type):
        """Initialize a sensor instance."""
        self.identifier = identifier
        self.sensor_type = sensor_type


sensor1 = Sensor("013", "temperature")
sensor2 = Sensor("051", "temperature")
sensor3 = Sensor("408", "humidity")

print(sensor1)
print(sensor1.identifier)
print(sensor1.sensor_type)
