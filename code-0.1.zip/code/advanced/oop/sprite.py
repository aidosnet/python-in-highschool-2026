"""
Define a minimal Sprite class.

This object-oriented programming example stores a sprite name and its position
on a two-dimensional plane.
"""

__author__ = "Mauri"
__version__ = "1.0"
__status__ = "Educational example"


class Sprite:
    """Represent a generic sprite with a name and position."""

    def __init__(self, name, x, y):
        """Initialize a sprite instance."""
        self.name = name
        self.x = x
        self.y = y

    @staticmethod
    def get_name():
        """Return a placeholder sprite name."""
        return 123
