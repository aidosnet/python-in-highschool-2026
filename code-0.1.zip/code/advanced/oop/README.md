# Object-Oriented Programming Examples

Small examples that introduce classes, dataclasses, object attributes, and
string representations.

## Files

- `class_sensor1.py`: defines a simple `Sensor` dataclass.
- `class_sensor2.py`: defines a basic `Sensor` class with `__str__`.
- `class_sensor3.py`: extends the sensor class example.
- `sprite.py`: defines a minimal `Sprite` class.

## Run

From the repository root:

```bash
python oop/class_sensor1.py
python oop/class_sensor2.py
python oop/class_sensor3.py
```

