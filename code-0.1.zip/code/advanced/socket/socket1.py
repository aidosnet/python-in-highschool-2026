"""
Create a TCP socket and connect it to Google's web server.

This introductory example shows how to create a socket, resolve a host name,
and open a connection to the HTTP port of a remote server.

Reference:
    https://www.geeksforgeeks.org/python/socket-programming-python/
"""

__author__ = "Mauri"
__version__ = "1.0"
__status__ = "Educational example"

import socket
import sys


try:
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    print("Socket successfully created")
except socket.error as error:
    print(f"Socket creation failed with error {error}")

# Use the default HTTP port.
port = 80

try:
    host_ip = socket.gethostbyname("www.google.com")
except socket.gaierror:
    print("There was an error resolving the host")
    sys.exit()

# Connect to the remote server.
client_socket.connect((host_ip, port))

print("The socket has successfully connected to Google")
