# Socket Examples

Introductory TCP socket examples written in Python.

## Files

- `socket1.py`: creates a TCP socket and connects to Google's HTTP port.
- `socket2_server.py`: starts a local server on port `12345`.
- `socket2_client.py`: connects to the local server and prints its message.

## Run

From the repository root:

```bash
python socket/socket1.py
```

For the local client/server example, open two terminals.

Terminal 1:

```bash
python socket/socket2_server.py
```

Terminal 2:

```bash
python socket/socket2_client.py
```

