"""
Run a simple TCP server that sends one message to a client.

This introductory server example binds to port 12345, waits for a client
connection, sends a short text message, and closes the connection.

Reference:
    https://www.geeksforgeeks.org/python/socket-programming-python/
"""

__author__ = "Mauri"
__version__ = "1.0"
__status__ = "Educational example"

import socket


# Create a socket object.
server_socket = socket.socket()
print("Socket successfully created")

# Reserve a local port.
port = 12345

# Bind the socket to all available network interfaces.
server_socket.bind(("", port))
print(f"Socket bound to {port}")

# Put the socket into listening mode.
server_socket.listen(5)
print("Socket is listening")

# Accept one client connection.
while True:
    client_socket, address = server_socket.accept()
    print(f"Got connection from {address}\n")

    # Send a message to the client. The string is encoded as bytes.
    client_socket.send("Thank you for connecting\n\n".encode())

    # Close the connection with the client.
    client_socket.close()
    break
