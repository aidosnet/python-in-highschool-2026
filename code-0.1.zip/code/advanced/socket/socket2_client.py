"""
Connect to a local TCP server and print the received message.

This introductory client example connects to localhost on port 12345, receives
one message from the server, prints it, and closes the connection.

Reference:
    https://www.geeksforgeeks.org/python/socket-programming-python/
"""

__author__ = "Mauri"
__version__ = "1.0"
__status__ = "Educational example"

import socket


# Create a socket object.
client_socket = socket.socket()

# Define the server port.
port = 12345

# Connect to the server on the local computer.
client_socket.connect(("127.0.0.1", port))

# Receive data from the server and decode it as a string.
print(client_socket.recv(1024).decode())

# Close the connection.
client_socket.close()
