"""
Visualizza un quadrato giallo.

"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "1.0 2021-01-20"

import py5
from py5 import *


def settings():
    """Initialize the drawing window."""
    size(800, 450)


def setup():
    """Init function is executed one time when the program starts."""
    background(255)
    fill(255, 255, 0)  # Imposta il colore giallo come colore di riempimento


def draw():
    """Executed repeatedly."""
    # background(255)
    fill(255, 255, 255, 50)
    rect(0, 0, py5.width, py5.height)
    fill(255, 255, 0)  # Imposta il colore giallo come colore di riempimento
    square(py5.mouse_x, py5.mouse_y, 100)  # x, y, side
    # print(str(py5.mouse_x) + ", " + str(py5.mouse_y))
    # print(f"{py5.mouse_x},{py5.mouse_y}")


run_sketch()  # Run the py5 sketch
