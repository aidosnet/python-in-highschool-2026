"""Check whether a year is leap year."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "2025-11-12"

# Input
year = int(input("Year? "))

# Processing
is_leap_year = (year % 4 == 0 and year % 100 != 0) or year % 400 == 0

# Output
if is_leap_year:
    print(year, "is a leap year")
else:
    print(year, "is not a leap year")
