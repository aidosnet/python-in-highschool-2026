"""Draw random dots."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"

from random import randint
from turtle import *

penup()
colormode(255)
speed(0)
shape("turtle")

for i in range(100):
    x = randint(-400, 400)
    y = randint(-400, 400)
    r = randint(200, 255)
    g = randint(0, 100)
    b = randint(0, 255)
    size = randint(10, 50)
    
    goto(x, y)
    color(r, g, b)
    # stamp()
    dot(size)
