"""
Continuously draw rotated squares.
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "0.1 2022-11-22"

import turtle

ninja = turtle.Turtle()
print(type(ninja))
ninja.speed(0)
size = 100

avanti = ninja.fd
ruota = ninja.left

# Draw continuously rotating squares of a given size
while True:  # Forever
    for _ in range(4):
        avanti(size)
        ruota(90)
        
    ninja.left(13)
