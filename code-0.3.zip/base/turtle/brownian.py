"""Programma che simula il comportamento di due particelle immerse in un 
fluido che si muovono con moto browniano.
"""

import turtle as t
from random import random

n = 500  # Numero di spostamenti
step = 10  # Massimo numero di passi (in pixel) per il singolo spostamento 
t.speed(0)

for color in "red", "blue": 
    t.goto(0, 0) 
    t.pencolor(color)
    
    for i in range(n):
        t.left(random() * 360) 
        t.forward(random() * step)