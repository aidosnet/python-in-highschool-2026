"""Draw colored vertical lines using a for loop."""

__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "2.0 2026-05-24"

import turtle

distance = 20  # eval(input("Distance: "))
length = 100  # eval(input("Length: "))
pen_size = 5  # eval(input("Pen size: "))
colors = ["red", "green", "blue", "violet"]

ninja = turtle.Turtle()
ninja.pensize(pen_size)
ninja.shape("turtle")

for color in colors:
    ninja.pendown()
    ninja.pencolor(color)
    ninja.forward(length)
    ninja.penup()
    ninja.backward(length)
    ninja.left(90)
    ninja.forward(distance)
    ninja.right(90)

ninja.pencolor("black")
turtle.done()
