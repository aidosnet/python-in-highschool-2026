__author__ = "maurizio.boscaini@marconiverona.edu.it"


def render_html(template_filename, values):
    """Createte the HTML document from the template
    e dal dizionari dei segnaposto."""
    with open(template_filename, encoding="utf-8") as file:
        html = file.read()

    for key, value in values.items():
        html = html.replace(f"<% {key} %>", value)

    return html


def txt_to_html(filename):
    """Restituisce il contenuto di un file di testo,
    sostituendo i caratteri di a capo con il tag <br>."""
    with open(filename, encoding="utf-8") as file:
        text = file.read()

    html = text.replace("\n", "<br>\n")
    return html


def highlight_words(text, words):
    """Restituisce un testo HTML con i termini indicati marcati."""
    html = text

    for key, value in words.items():
        html = html.replace(key, f"<span class='{value}'>{key}</span>")
    return html


if __name__ == "__main__":
    text_filename = "./data/1984.txt"
    html = txt_to_html(text_filename)
    words = {"the": "article", "April": "time", "Winston": "main-character"}
    body = highlight_words(html, words)

    template_filename = "assets/template/page_template.html"
    values = {"title": "Highlight words 1", "body": body}
    html = render_html(template_filename, values)

    filename = "1984_highlighted.html"

    with open(filename, encoding="utf-8", mode="w") as file:
        file.write(html)
