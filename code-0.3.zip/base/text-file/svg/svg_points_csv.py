__author__ = "maurizio.boscaini@marconiverona.edu.it"

import random


def svg_points_csv(filename, width, height):
    """Return part of an SVG document with the points
    definiti in un file .csv con il seguente tracciato record:
    x,y,radius,color
    """
    svg = ""

    for line in open(filename):
        x, y, r, color = line.strip().split(",")
        svg += f"""<circle cx="{x}" cy="{y}" r="{r}" fill="{color}" />\n1"""

    return svg


def write_svg_document(body, filename, width=800, height=600):
    """Scrive in un file un documento SVG"""
    svg_start = f"""<?xml version="1.0"?>
        <svg width="{width}" height="{height}" xmlns="http://www.w3.org/2000/svg">
    """
    svg_end = "</svg>"

    with open(filename, "w") as file:
        file.write(svg_start + body + svg_end)


if __name__ == "__main__":
    width, height = 800, 600
    body = svg_points_csv("data/points.csv", width, height)
    write_svg_document(body, "svg_points_csv.svg", width, height)
