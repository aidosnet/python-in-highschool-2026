__author__ = "maurizio.boscaini@marconiverona.edu.it"

import random
from math import sin, cos, pi

def svg_random_polygons(n, width, height):
    """Restituisce un parte di documento SVG con n poligoni (meglio se regolari) casuali.
    In particular, these are random: fill color, number of sides,
    la lunghezza del lato (entro opportuni intervalli)."""
    svg = ""
    
    for i in range(n):
        points = ""        
        sides = random.randint(3, 8)
        radius = random.randint(10, 100)
        xc = random.randint(0, width - 1)
        yc = random.randint(0, height - 1)
        
        for side in range(sides):
            angle = 2*pi / sides * side
            angle += random.randint(0, 10)
                                    
            if sides % 2 == 0:
                angle -= 2*pi / sides*0.5
            else:
                angle -= 2*pi / sides / (sides + 1)
                
            x = xc + radius * cos(angle)
            y = yc + radius * sin(angle)
            points += f"{int(x)},{int(y)} "
        
        r = random.randint(0, 255)
        g = random.randint(0, 255)
        b = random.randint(0, 255)
        svg += f'<polygon points="{points}" strokewidth="1" stroke="black" fill="rgb({r}, {g}, {b})" />'
    return svg

def write_svg_document(body, filename, width=800, height=600):
    """Scrive in un file un documento SVG"""
    svg_start = f"""<?xml version="1.0"?>
        <svg width="{width}" height="{height}" xmlns="http://www.w3.org/2000/svg">
    """
    svg_end = """
        </svg>
    """
    with open(filename, "w") as file:
        file.write(svg_start)
        file.write(body)
        file.write(svg_end)

if __name__ == "__main__":
    width, height = 800, 600
    body = svg_random_polygons(100, width, height)
    write_svg_document(body, "random_polygons.svg", width, height)
