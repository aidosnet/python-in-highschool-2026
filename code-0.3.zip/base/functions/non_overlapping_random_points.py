"""
Draw non-overlapping random points on the canvas.
"""

__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "1.0 2022-12-16"

from turtle import Screen, Turtle, setworldcoordinates, colormode
from random import randint, seed
from math import sqrt

def init(w, h):
    """Initialize the drawing environment with a w x h canvas and the origin in the upper-left corner."""
    screen = Screen()
    screen.setup(w, h)
    # Sistema di riferimento della computer grafica (0, 0) in alto a turn_left
    setworldcoordinates(0, h, w, 0)   
    
def draw_points(n, w, h):
    """Draw n random points on the canvas."""
    dot_coords = []
    colormode(255)
    ninja = Turtle()
    ninja.hideturtle()
    ninja.speed(0)
    ninja.up()
    seed(0)
    extent = 20
    
    for i in range(n):
        r, g, b = randint(0, 255), randint(0, 255), randint(0, 255)
        x = randint(0, w)
        y = randint(0, h)
        
        if not collide((x, y), dot_coords, extent):
            ninja.goto(x, y)
            ninja.color(r, g, b)
            ninja.dot(extent)
            dot_coords.append((x, y))

def collide(dot_coord, dot_coords, extent):
    """Check whether a dot collides with another dot in a list."""
    for x, y in dot_coords:
        dx = x - dot_coord[0]
        dy = y - dot_coord[1]
        
        if sqrt(dx**2 + dy**2) < extent:
            return True
    
    return False

if __name__ == "__main__":
    w, h = 800, 450
    init(w, h)
    draw_points(100, w, h)




