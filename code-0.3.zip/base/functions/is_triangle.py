__author__ = "maurizio.boscaini@marconiverona.edu.it"
__version__ = "0.1 2020-12-11"


def is_triangle(side_a, side_b, side_c):
    """Return True if the three sides can form a triangle, False otherwise.

    >>> is_triangle(3, 4, 5)
    True
    >>> is_triangle(3, 4, 9)
    False
    >>> is_triangle(0, 4, 5)
    False
    >>> is_triangle(-3, -4, -5)
    False
    >>> a = 7
    >>> b = 6
    >>> c = a + b / 2
    >>> is_triangle(a, b, c)
    True
    """
    return side_a > 0 and side_b > 0 and side_c > 0 and side_a < side_b + side_c and side_b < side_a + side_c and side_c < side_a + side_b


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)
