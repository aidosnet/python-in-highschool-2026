__author__ = "maurizio.boscaini@marconiverona.edu.it"

from random import random

def pi_greco(n: int) -> float:
    """Calculate an approximation of pi.
    utilizzando il metodo Monte Carlo, utilizzando n gocce elettroniche"""
    _sum = 0
    
    for _ in range(n):
        x = random()  # [0, 1)
        y = random()
        
        d = x*x + y*y 
        
        if d < 1:
            _sum += 1
    
    return 4 * _sum / n

if __name__ == "__main__":
    print(pi_greco(10000000))


