"""
Animazione 2D realizzata con py5 di un personaggio (pikachu) in movimento orizzontale accompagnato da effetti grafici (fulmini e flash luminosi)


Il programma gestisce:
- Caricamento e animazione di una sequenza di immagini (sprite animation)
- Generazione di fulmini orientati in diverse direzioni
- Effetto flash (fade-out)
- Aggiornamento e rendering separati della logica e della grafica

Struttura:
- setup() -> inizializzazione risorse e variabili
- draw() -> ciclo principale di aggiornamento e disegno
- Funzioni di supporto per gestione fulmini e flash

@author Oleksii Holovan
@author Gabriel Zanoni
@version 7.0 2026-02-(16-21)
"""

import py5
import math

# ------------------ COSTANTI UTENTE (si può modificare) ------------------
N = 10
LIGHTNING_SPEED_X = 15
LIGHTNING_SPEED_Y = 15
ANGLE_START = 45
ANGLE_END = 165
PIKACHU_STOP_X = 700

# ------------------ COSTANTI PROGRAMMA (NON si può modificare) ------------------
WIDTH = 1200
HEIGHT = 1000

FPS_RUN = 15
FPS_LIGHTNING = 60

RUN_FRAMES = 4
LIGHTNING_FRAMES = 106

RUN_BASENAME = "pikachu-running/pikachu-running_"
LIGHTNING_BASENAME = "pikachu-lightning/frame_"

RUN_SPEED = 30

BLAST_START = 39

FLASH_START_ALPHA = 200
FLASH_FADE_SPEED = 15

# ------------------ STATO ------------------

running_images = []
lightning_images = []

scene = "run"
frame_index = 0

pikachu_x = -600

lightnings = []
flash_alpha = 0

# ------------------ INIZIALIZZAIONE ------------------
def settings():
    """Imposta dimensioni della finestra"""
    py5.size(WIDTH, HEIGHT)

def setup():
    """
    Carica le risorse necessarie: immagini per il personaggio e shape del fulmine
    """
    py5.frame_rate(FPS_RUN)
    load_images()
    create_lightning_shape()
    generate_lightning_starting_parameters()

def load_images():
    """Carica le immagini per entrambe le scene per l'animazione del personaggio"""
    for i in range(1, RUN_FRAMES + 1):
        filename = f"{RUN_BASENAME}{i:03}.gif"
        image = py5.load_image(filename)
        running_images.append(image)

    for i in range(1, LIGHTNING_FRAMES + 1):
        filename = f"{LIGHTNING_BASENAME}{i:03}.gif"
        image = py5.load_image(filename)
        lightning_images.append(image)

def create_lightning_shape():
    """Funzione chiamata 1 volta che crea la shape del fulmine"""
    global lightning_shape

    py5.stroke(0)
    py5.stroke_weight(2)
    py5.fill(255, 215, 0)

    lightning_shape = py5.create_shape()
    lightning_shape.begin_shape()

    # form left to right top
    lightning_shape.vertex(50, -100)
    lightning_shape.vertex(15, -100)

    # down and right
    lightning_shape.vertex(-10, -50)
    lightning_shape.vertex(15, -50)

    # down and up
    lightning_shape.vertex(0, 0)
    lightning_shape.vertex(40, -65)

    # final left
    lightning_shape.vertex(20, -65)

    # automatic close shape
    lightning_shape.end_shape(py5.CLOSE) 

def generate_lightning_starting_parameters():
    """
    Calcola e memorizza i parametri iniziali di spawn dei fulmini.

    La funzione viene eseguita durante la fase di setup e determina:

    - Il punto più a sinistra del corpo di Pikachu 
    - Il punto più a destra del corpo di Pikachu 
    
    I fulmini partono con una coordinata X casuale compresa tra
    il punto sinistro e il punto destro del corpo di Pikachu.

    - L'altezza (coordinata Y) del corpo di Pikachu da cui partono i fulmini

    I valori vengono calcolati una sola volta utilizzando:
    - La posizione finale di arresto del personaggio
    - Le dimensioni dell'immagine utilizzata per l'animazione dei fulmini

    I risultati vengono salvati in variabili globali per evitare ricalcoli
    ad ogni frame durante la scena dei fulmini.
    """

    global LIGHTNING_SPAWN_LEFT, LIGHTNING_SPAWN_RIGHT, LIGHTNING_SPAWN_Y

    LIGHTNING_SPAWN_LEFT = PIKACHU_STOP_X + lightning_images[0].width * 0.4
    LIGHTNING_SPAWN_RIGHT = PIKACHU_STOP_X + lightning_images[0].width * 0.65
    LIGHTNING_SPAWN_Y = HEIGHT // 2 + lightning_images[0].height // 2


# ------------------ DRAW ------------------

def draw():
    """Funzione principale che aggiorna lo schermo e gestisce le 2 scene"""
    global scene
    py5.background(255)

    if scene == "run":
        update_run_scene()
    elif scene == "lightning":
        update_lightning_scene()

# ------------------ RUN SCENE ------------------

def update_run_scene():
    
    global frame_index, pikachu_x, scene

    img = running_images[frame_index]
    y = HEIGHT // 2 + img.height // 2

    py5.image(img, pikachu_x, y)

    frame_index = (frame_index + 1) % RUN_FRAMES
    pikachu_x += RUN_SPEED

    if pikachu_x > PIKACHU_STOP_X:
        scene = "lightning"
        frame_index = 0
        py5.frame_rate(FPS_LIGHTNING)

# ------------------ LIGHTNING SCENE ------------------

def update_lightning_scene():
    global frame_index, flash_alpha

    img = lightning_images[frame_index]
    y = HEIGHT // 2

    py5.image(img, pikachu_x, y)

    if frame_index == BLAST_START:
        generate_lightnings()
        flash_alpha = FLASH_START_ALPHA

    frame_index = (frame_index + 1) % LIGHTNING_FRAMES
    
    draw_lightnings()
    update_lightnings()
    update_flash()


# ------------------ LOGICA FULMINI ------------------

def generate_lightnings():
    lightnings.clear()

    for _ in range(N):
        angle = py5.random(ANGLE_START, ANGLE_END)
        rad = py5.radians(angle)

        lightnings.append({
            "x": py5.random(LIGHTNING_SPAWN_LEFT, LIGHTNING_SPAWN_RIGHT), 
            "y": LIGHTNING_SPAWN_Y, # partono sempre dalla stessa altezza
            "angle": -py5.radians(angle - 90), # cambio segno cosi gira a sinistra (angoli matematici) e non a destra (angoli schermo (py5) ) ; - 90 perchè il nostro lightning è gia disegnato a +90 gradi
            "dx": math.cos(rad),
            "dy": -math.sin(rad),
        })

def draw_lightnings():
    """Disegna il fulmine chiamando draw_lightning"""
    for l in lightnings:
        draw_lightning(l["x"], l["y"], l["angle"])

def update_lightnings():
    """
    Aggiorna lo stato dei fulmini attivi.

    Per ogni fulmine:
    - Cambia la posizione orizontale del fulmine
    - Cambia la posizione verticale del fulmine
    """
    for l in lightnings:

        l["x"] += LIGHTNING_SPEED_X * l["dx"]
        l["y"] += LIGHTNING_SPEED_Y * l["dy"]

# ------------------ LIGHTNING SHAPE ------------------

def draw_lightning(x, y, angle):
    """Disegna un fulmine usando la shape creata durante la fase di setup"""

    py5.push_matrix() # salva il sistema di coordinate
    py5.translate(x, y) # muove l'origine dove ci deve essere il fulmine
    py5.rotate(angle)
    py5.shape(lightning_shape)
    py5.pop_matrix() # ripristina automaticamente (0, 0)


# ------------------ FLASH EFFECT ------------------

def update_flash():
    """Funzione che gestisce lo flash e la sua trasparenza"""
    global flash_alpha

    if flash_alpha > 0:
        py5.no_stroke()
        py5.fill(255, 215, 0, flash_alpha)
        py5.rect(0, 0, WIDTH, HEIGHT)
        flash_alpha -= FLASH_FADE_SPEED


py5.run_sketch()