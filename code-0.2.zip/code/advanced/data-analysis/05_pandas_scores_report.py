"""
Create a richer student score report with pandas and matplotlib.

This example loads the student score CSV file, calculates summary tables, saves
a new CSV report, and creates a bar chart with average score by subject.
"""

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
SCORES_FILE = DATA_DIR / "student_scores.csv"
SUMMARY_FILE = OUTPUT_DIR / "subject_summary.csv"
CHART_FILE = OUTPUT_DIR / "subject_average_scores.png"


def create_subject_summary(scores_file: Path) -> pd.DataFrame:
    """Return average, minimum, and maximum scores grouped by subject."""
    data = pd.read_csv(scores_file)

    summary = data.groupby("subject")["score"].agg(["mean", "min", "max"])
    summary = summary.reset_index()
    summary["mean"] = summary["mean"].round(2)

    return summary


def save_summary(summary: pd.DataFrame, filename: Path) -> None:
    """Save the subject summary to a CSV file."""
    OUTPUT_DIR.mkdir(exist_ok=True)
    summary.to_csv(filename, index=False)


def save_subject_chart(summary: pd.DataFrame, filename: Path) -> None:
    """Save a bar chart with average score by subject."""
    OUTPUT_DIR.mkdir(exist_ok=True)

    plt.figure(figsize=(8, 5))
    bars = plt.bar(summary["subject"], summary["mean"])
    plt.title("Average Score by Subject")
    plt.xlabel("Subject")
    plt.ylabel("Average score")
    plt.ylim(60, 100)

    for bar in bars:
        height = bar.get_height()
        plt.text(
            bar.get_x() + bar.get_width() / 2,
            height + 0.5,
            f"{height:.1f}",
            ha="center",
        )

    plt.tight_layout()
    plt.savefig(filename)
    plt.close()


if __name__ == "__main__":
    if not SCORES_FILE.exists():
        print("Run 01_create_student_scores.py first to create the scores CSV file.")
    else:
        subject_summary = create_subject_summary(SCORES_FILE)
        save_summary(subject_summary, SUMMARY_FILE)
        save_subject_chart(subject_summary, CHART_FILE)

        print(subject_summary)
        print(f"Saved summary to {SUMMARY_FILE}")
        print(f"Saved chart to {CHART_FILE}")
