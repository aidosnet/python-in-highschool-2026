"""
Create a CSV file with example student scores.

This first data-analysis example writes a small dataset to a CSV file. The file
is used by the next examples in this folder.
"""

import os

FILENAME = "data/student_scores.csv"


def create_student_scores(filename: str) -> None:
    """Create a CSV file with student names, subjects, and scores."""
    os.makedirs("data", exist_ok=True)

    rows: list = [
        "student,subject,score",
        "Alice,Math,82",
        "Alice,Science,91",
        "Alice,English,78",
        "Bob,Math,74",
        "Bob,Science,68",
        "Bob,English,80",
        "Carla,Math,95",
        "Carla,Science,88",
        "Carla,English,92",
        "Diego,Math,63",
        "Diego,Science,72",
        "Diego,English,70",
        "Emma,Math,89",
        "Emma,Science,94",
        "Emma,English,85",
    ]

    with open(filename, "w", encoding="utf-8") as file:
        for row in rows:
            file.write(row + "\n")


if __name__ == "__main__":
    create_student_scores(FILENAME)
    print(f"Created {FILENAME}")
