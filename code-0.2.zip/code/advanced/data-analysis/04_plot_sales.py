"""
Plot monthly sales data with matplotlib.

This example reads sales data from a CSV file, calculates monthly revenue, and
saves a line chart as a PNG image.
"""

import csv
from pathlib import Path

import matplotlib.pyplot as plt


BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
FILENAME = DATA_DIR / "monthly_sales.csv"
CHART_FILE = OUTPUT_DIR / "monthly_revenue.png"


def load_sales(filename: Path) -> list:
    """Read sales records from a CSV file."""
    sales: list = []

    with open(filename, "r", encoding="utf-8", newline="") as file:
        reader = csv.DictReader(file)

        for row in reader:
            sale: dict = {
                "month": row["month"],
                "product": row["product"],
                "units": int(row["units"]),
                "revenue": int(row["revenue"]),
            }
            sales.append(sale)

    return sales


def revenue_by_month(sales: list) -> dict:
    """Return total revenue grouped by month."""
    totals: dict = {}

    for sale in sales:
        month: str = sale["month"]

        if month not in totals:
            totals[month] = 0

        totals[month] += sale["revenue"]

    return totals


def save_revenue_chart(monthly_revenue: dict, filename: Path) -> None:
    """Save a line chart with total revenue by month."""
    OUTPUT_DIR.mkdir(exist_ok=True)

    months: list = list(monthly_revenue.keys())
    revenues: list = list(monthly_revenue.values())

    plt.figure(figsize=(8, 5))
    plt.plot(months, revenues, marker="o")
    plt.title("Monthly Revenue")
    plt.xlabel("Month")
    plt.ylabel("Revenue")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(filename)
    plt.close()


if __name__ == "__main__":
    if not FILENAME.exists():
        print("Run 03_sales_summary.py first to create the sales CSV file.")
    else:
        sales = load_sales(FILENAME)
        monthly_revenue = revenue_by_month(sales)
        save_revenue_chart(monthly_revenue, CHART_FILE)
        print(f"Saved chart to {CHART_FILE}")

