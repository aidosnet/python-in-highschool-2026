# Data Analysis Examples

Small educational programs that create CSV files and analyze data with
increasing complexity.

## Files

- `01_create_student_scores.py`: creates a CSV file with student scores.
- `02_basic_scores_analysis.py`: reads the CSV file manually and prints simple statistics.
- `03_sales_summary.py`: creates and analyzes monthly sales data with the `csv` module.
- `04_plot_sales.py`: creates charts from sales data with `matplotlib`.
- `05_pandas_scores_report.py`: creates a richer report with `pandas` and `matplotlib`.

## Requirements

The first three examples only need Python 3.

For plotting:

```bash
pip install matplotlib
```

For the pandas report:

```bash
pip install pandas matplotlib
```

## Run

From the repository root:

```bash
python data-analysis/01_create_student_scores.py
python data-analysis/02_basic_scores_analysis.py
python data-analysis/03_sales_summary.py
python data-analysis/04_plot_sales.py
python data-analysis/05_pandas_scores_report.py
```

Generated CSV files are saved in `data-analysis/data/`.
Generated chart images are saved in `data-analysis/output/`.

