"""
Create and analyze monthly sales data with the standard csv module.

This example creates a CSV file, reads it back, and prints totals by product.
It is a small step up from manual string splitting.
"""

import csv
from pathlib import Path


BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
FILENAME = DATA_DIR / "monthly_sales.csv"


def create_sales_csv(filename: Path) -> None:
    """Create a CSV file with monthly sales by product."""
    DATA_DIR.mkdir(exist_ok=True)

    rows: list = [
        ["month", "product", "units", "revenue"],
        ["January", "Keyboard", 34, 1700],
        ["January", "Mouse", 58, 1450],
        ["January", "Monitor", 18, 3600],
        ["February", "Keyboard", 42, 2100],
        ["February", "Mouse", 63, 1575],
        ["February", "Monitor", 21, 4200],
        ["March", "Keyboard", 38, 1900],
        ["March", "Mouse", 70, 1750],
        ["March", "Monitor", 25, 5000],
        ["April", "Keyboard", 51, 2550],
        ["April", "Mouse", 77, 1925],
        ["April", "Monitor", 29, 5800],
    ]

    with open(filename, "w", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerows(rows)


def load_sales(filename: Path) -> list:
    """Read sales records from a CSV file."""
    sales: list = []

    with open(filename, "r", encoding="utf-8", newline="") as file:
        reader = csv.DictReader(file)

        for row in reader:
            sale: dict = {
                "month": row["month"],
                "product": row["product"],
                "units": int(row["units"]),
                "revenue": int(row["revenue"]),
            }
            sales.append(sale)

    return sales


def revenue_by_product(sales: list) -> dict:
    """Return total revenue grouped by product."""
    totals: dict = {}

    for sale in sales:
        product: str = sale["product"]

        if product not in totals:
            totals[product] = 0

        totals[product] += sale["revenue"]

    return totals


if __name__ == "__main__":
    create_sales_csv(FILENAME)
    sales = load_sales(FILENAME)
    totals = revenue_by_product(sales)

    print(f"Created {FILENAME}")
    print("Revenue by product:")

    for product, revenue in totals.items():
        print(f"- {product}: {revenue}")

