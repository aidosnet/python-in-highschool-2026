"""
Analyze student scores from a CSV file without external libraries.

This example reads a CSV file manually with `split(",")`, calculates simple
statistics, and prints a short report.
"""

FILENAME = "data/student_scores.csv"


def load_scores(filename: str) -> list:
    """Read student scores from a CSV file and return a list of dictionaries."""
    scores: list = []

    with open(filename, "r", encoding="utf-8") as file:
        lines: list = file.readlines()

    for line in lines[1:]:
        line = line.strip()

        if line == "":
            continue

        parts: list = line.split(",")
        score: dict = {
            "student": parts[0],
            "subject": parts[1],
            "score": int(parts[2]),
        }
        scores.append(score)

    return scores


def average_score(scores: list) -> float:
    """Return the average score for all records."""
    total: int = 0

    for score in scores:
        total += score["score"]

    return total / len(scores)


def highest_score(scores: list) -> dict:
    """Return the record with the highest score."""
    best_score: dict = scores[0]

    for score in scores:
        if score["score"] > best_score["score"]:
            best_score = score

    return best_score


def count_passed(scores: list, minimum_score: int) -> int:
    """Count how many records have a score greater than or equal to a limit."""
    count: int = 0

    for score in scores:
        if score["score"] >= minimum_score:
            count += 1

    return count


if __name__ == "__main__":
    scores = load_scores(FILENAME)
    best = highest_score(scores)

    print("Records:", len(scores))
    print("Average score:", round(average_score(scores), 2))
    print("Passed records:", count_passed(scores, 70))
    print("Highest score:", best["student"], best["subject"], best["score"])
