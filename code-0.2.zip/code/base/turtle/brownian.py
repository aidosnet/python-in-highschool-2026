"""Programma che simula il comportamento di due particelle immerse in un 
fluido che si muovono con moto browniano.
"""

import turtle 
import random

n = 1000  # Numero di spostamenti
step = 10  # Massimo numero di passi (in pixel) per il singolo spostamento 
turtle.speed(0)

for color in "red", "blue": 
    turtle.goto(0, 0) 
    turtle.pencolor(color)
    
    for i in range(n):
        turtle.left(random.random() * 360) 
        turtle.forward(random.random() * step)